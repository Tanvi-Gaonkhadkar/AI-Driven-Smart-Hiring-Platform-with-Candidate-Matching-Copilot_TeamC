from numpy.__config__ import show
import streamlit as st



def route_user():

    role = st.session_state.get("role")

    if role == "candidate":
        st.switch_page("pages/candidate.py")

    elif role == "employee":
        st.switch_page("pages/employee.py")

    elif role == "recruiter":
        st.switch_page("pages/recruiter.py")

    elif role == "admin":
        st.switch_page("pages/admin.py")

    else:
        st.error("Role not assigned")