"""
login.py
---------
Professional login gate for the AI Recruitment Copilot.

HOW TO WIRE THIS INTO YOUR EXISTING APP:

    import streamlit as st
    from login import require_login

    require_login()   # <-- put this as the very first line after st.set_page_config()

    # ... rest of your existing app.py code (sidebar, pages, etc.) goes here,
    # completely unchanged.

CREDENTIALS SETUP (.streamlit/secrets.toml):

    [auth]
    username = "your_admin_username"
    password = "your_strong_password"

    You can add multiple users if needed:

    [auth.users]
    hr_admin = "password1"
    recruiter1 = "password2"

For production use, never commit secrets.toml to git — add it to .gitignore.
When you deploy on Streamlit Community Cloud, paste the same contents into
the app's "Secrets" panel in the dashboard instead of uploading the file.
"""

import streamlit as st
import time


def _inject_css():
    st.markdown("""
    <style>

    /* Hide Streamlit UI */
    #MainMenu {visibility: hidden;}
    header {visibility: hidden;}
    footer {visibility: hidden;}

    /* Remove default padding */
    .block-container {
        padding-top: 0 !important;
        padding-bottom: 0 !important;
        max-width: 100%;
    }

    section.main > div {
        padding-top: 0 !important;
    }

    /* Center content vertically */
    [data-testid="stAppViewContainer"] > .main {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    /* Background */
    .stApp {
        background: linear-gradient(
            135deg,
            #B4E1EB 0%,
            #95BDD7 45%,
            #FFBE91 100%
        );
    }

    /* Login Card */
    image {
        background: rgba(255,255,255,0.97);
        border-radius: 22px;
        padding: 40px;
        border: 1px solid rgba(255,255,255,0.25);
        box-shadow: 0 20px 60px rgba(0,0,0,0.25);
        margin-top: 0;
    }

   
    /* Title */
    .login-title {
        text-align: center;
        font-size: 26px;
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 6px;
    }

    /* Subtitle */
    .login-subtitle {
        text-align: center;
        color: #000000;
        font-size: 15px;
        margin-bottom: 28px;
    }

    /* Textboxes */
    div[data-testid="stTextInput"] input {
        border-radius: 12px;
        border: 2px solid #dbeafe;
        padding: 12px;
        transition: all .2s ease;
    }

    div[data-testid="stTextInput"] input:focus {
        border-color: #2563eb !important;
        box-shadow: 0 0 0 4px rgba(37,99,235,.12);
    }

    /* Login Button */
    div[data-testid="stFormSubmitButton"] button {
        width: 100%;
        height: 50px;
        border: none;
        border-radius: 12px;
        background: linear-gradient(135deg,#2563eb,#1d4ed8);
        color: white;
        font-size: 16px;
        font-weight: 600;
        transition: all .25s ease;
    }

    div[data-testid="stFormSubmitButton"] button:hover {
        background: linear-gradient(135deg,#1d4ed8,#1e40af);
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(37,99,235,.35);
    }

    /* Footer */
    .login-footer {
        text-align: center;
        color: #94a3b8;
        font-size: 12px;
        margin-top: 20px;
    }

    </style>
    """, unsafe_allow_html=True)

def _check_credentials(username: str, password: str) -> bool:
    """
    Validate user credentials stored in Streamlit Secrets.

    Supports:
    1. Single user:
        [auth]
        username = "admin"
        password = "password"

    2. Multiple users:
        [auth.users]
        hr_admin = "password1"
        recruiter1 = "password2"
    """

    try:
        auth = st.secrets.get("auth", {})

        # Single-user authentication
        if (
            auth.get("username") == username
            and auth.get("password") == password
        ):
            return True

        # Multi-user authentication
        users = auth.get("users", {})
        if users.get(username) == password:
            return True

        return False

    except Exception:
        return False


def _render_login_form():
    _inject_css()

    # Create centered columns
    left, center, right = st.columns([1, 0.8, 1])

    with center:

        st.markdown("""
        <div class="login-title">
            AI Recruitment Copilot
        </div>

        <div class="login-subtitle">
            Smart Hiring & Talent Management
        </div>
        """, unsafe_allow_html=True)

        with st.form("login_form", clear_on_submit=False):

            username = st.text_input(
                "Username",
                placeholder="Enter your username"
            )

            password = st.text_input(
                "Password",
                type="password",
                placeholder="Enter your password"
            )

            submitted = st.form_submit_button(
                "🔐 Sign In",
                use_container_width=True
            )

            if submitted:

                if _check_credentials(username, password):

                    st.session_state["logged_in"] = True
                    st.session_state["username"] = username

                    st.success("✅ Login successful!")

                    time.sleep(0.6)

                    st.rerun()

                else:

                    st.error("❌ Invalid username or password.")

        st.markdown("""
        <div class="login-footer">
            © 2026 AI Recruitment Copilot
        </div>
        """, unsafe_allow_html=True)

        st.markdown("</div>", unsafe_allow_html=True)

def require_login():
    """Call this at the top of your app. Blocks the rest of the app
    from rendering until the user is authenticated."""
    if "logged_in" not in st.session_state:
        st.session_state["logged_in"] = False

    if not st.session_state["logged_in"]:
        _render_login_form()
        st.stop()  # halts execution so nothing below this renders


def logout_button():
    if st.session_state.get("logged_in", False):

        st.sidebar.markdown("---")
        st.sidebar.write(
            f"👤 **{st.session_state.get('username')}**"
        )

        if st.sidebar.button("🚪 Logout", use_container_width=True):

            st.session_state.clear()

            st.rerun()