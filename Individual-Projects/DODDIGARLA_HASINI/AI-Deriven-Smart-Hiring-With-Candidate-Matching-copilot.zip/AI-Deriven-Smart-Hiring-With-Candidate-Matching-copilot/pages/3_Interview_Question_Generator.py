import streamlit as st

# MUST be the first Streamlit command
st.set_page_config(
    page_title="Interview Question Generator",
    layout="wide"
)

# Login first
from login import require_login
require_login()

# Sidebar after successful login
from sidebar import show_sidebar
show_sidebar()

# Other imports
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import ollama
from utils.resume_parser import extract_resume_text

# Hide default Streamlit navigation
st.markdown("""
<style>
[data-testid="stSidebarNav"] {
    display: none;
}
</style>
""", unsafe_allow_html=True)

st.title("🎤 Interview Question Generator AI")

# -----------------------------
# Inputs
# -----------------------------
tab1, tab2, tab3 = st.tabs([
    "Generate Questions",
    "Candidate Scoring",
    "AI Insights"
    
    ])

#================== tab 1 generate questions =========================
# ================== TAB 1 : Generate Questions =====================
with tab1:

    # Upload Resume
    uploaded_resume = st.file_uploader(
        "Upload Candidate Resume",
        type=["pdf", "docx", "txt"]
    )

    # Job Description
    job_description = st.text_area(
        "Paste Job Description",
        height=200
    )

    st.divider()

    col1, col2 = st.columns(2)

    with col1:
        interview_type = st.selectbox(
            "Interview Type",
            [
                "Technical",
                "HR",
                "Behavioral",
                "Managerial",
                "Final Round"
            ]
        )

    with col2:
        difficulty = st.selectbox(
            "Difficulty",
            [
                "Easy",
                "Medium",
                "Hard"
            ]
        )

    # -----------------------------
    # Generate Questions
    # -----------------------------
    if st.button("🎤 Generate Interview Questions", use_container_width=True):

        if uploaded_resume is None:
            st.warning("⚠ Please upload a resume.")
            st.stop()

        if not job_description.strip():
            st.warning("⚠ Please enter the Job Description.")
            st.stop()

        try:
            # Extract resume text
            resume_text = extract_resume_text(uploaded_resume)

            # Prompt for Llama
            prompt = f"""
You are an expert technical interviewer.

Generate 5 {difficulty} {interview_type} interview questions.

Job Description:
{job_description}

Candidate Resume:
{resume_text}

Requirements:
- Return only a numbered list.
- Questions should match the candidate's skills.
- Avoid repeating questions.
"""

            with st.spinner("Generating interview questions..."):

                response = ollama.chat(
                    model="llama3.2",
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                )

            answer = response["message"]["content"]

            # Save for other tabs
            st.session_state["generated_questions"] = answer
            st.session_state["job_description"] = job_description
            st.session_state["resume_text"] = resume_text

            st.success("✅ Questions Generated Successfully!")

            st.subheader(
                f"{interview_type} Interview Questions ({difficulty})"
            )

            st.markdown(answer)

        except Exception as e:
            st.error("❌ Failed to generate interview questions.")
            st.exception(e)
            uploaded_resume = st.file_uploader(
                "Upload Candidate Resume",
                type=["pdf", "docx", "txt"]
            )




# ================== TAB 2 : Candidate Scoring =====================
# ================== TAB 2 : Candidate Scoring =====================
with tab2:

    st.subheader("📝 Interview Evaluation")

    col1, col2, col3 = st.columns(3)

    with col1:
        technical = st.slider("Technical Knowledge", 0, 10, 7)
        coding = st.slider("Coding Skills", 0, 10, 7)
        projects = st.slider("Project Explanation", 0, 10, 8)

    with col2:
        problem = st.slider("Problem Solving", 0, 10, 7)
        communication = st.slider("Communication", 0, 10, 9)
        confidence = st.slider("Confidence", 0, 10, 8)

    with col3:
        behavior = st.slider("Behavioral Skills", 0, 10, 8)
        culture = st.slider("Cultural Fit", 0, 10, 8)

    # -----------------------------
    # Overall Score
    # -----------------------------
    scores = [
        technical,
        coding,
        problem,
        communication,
        confidence,
        projects,
        behavior,
        culture
    ]

    overall = round((sum(scores) / 80) * 100)

    st.divider()

    c1, c2, c3 = st.columns(3)

    c1.metric("Overall Match", f"{overall}%")

    if overall >= 85:
        c2.success("🟢 Highly Suitable")
    elif overall >= 70:
        c2.info("🟡 Suitable")
    else:
        c2.error("🔴 Needs Improvement")

    c3.metric("Interview Rating", f"{overall/10:.1f}/10")

    # -----------------------------
    # Gauge Chart
    # -----------------------------
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=overall,
        title={"text": "Candidate Match"},
        gauge={
            "axis": {"range": [0, 100]},
            "steps": [
                {"range": [0, 50], "color": "#ffcccc"},
                {"range": [50, 75], "color": "#fff3cd"},
                {"range": [75, 100], "color": "#d4edda"}
            ]
        }
    ))

    st.plotly_chart(fig, use_container_width=True)

    # -----------------------------
    # Radar Chart
    # -----------------------------
    radar = go.Figure()

    radar.add_trace(go.Scatterpolar(
        r=scores,
        theta=[
            "Technical",
            "Coding",
            "Problem Solving",
            "Communication",
            "Confidence",
            "Projects",
            "Behavior",
            "Culture"
        ],
        fill="toself",
        name="Candidate"
    ))

    radar.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 10]
            )
        ),
        showlegend=False
    )

    st.plotly_chart(radar, use_container_width=True)

    # -----------------------------
    # Bar Chart
    # -----------------------------
    df = pd.DataFrame({
        "Category": [
            "Technical",
            "Coding",
            "Problem Solving",
            "Communication",
            "Confidence",
            "Projects",
            "Behavior",
            "Culture"
        ],
        "Score": scores
    })

    fig = px.bar(
        df,
        x="Category",
        y="Score",
        text="Score",
        color="Score",
        color_continuous_scale="Viridis"
    )

    fig.update_yaxes(range=[0, 10])

    st.plotly_chart(fig, use_container_width=True)

    # -----------------------------
    # AI Recommendation
    # -----------------------------
    if st.button("🤖 Generate AI Recommendation"):

        prompt = f"""
You are an experienced HR Manager.

Job Description:
{job_description}

The interviewer gave the following scores:

Technical Knowledge: {technical}/10
Coding Skills: {coding}/10
Problem Solving: {problem}/10
Communication: {communication}/10
Confidence: {confidence}/10
Project Explanation: {projects}/10
Behavioral Skills: {behavior}/10
Cultural Fit: {culture}/10

Overall Match: {overall}%

Based on these interviewer scores and the job description, provide:

1. Candidate Summary
2. Strengths
3. Areas for Improvement
4. Suitability for the Role
5. Final Hiring Recommendation (Hire / Consider / Reject)

Keep the response concise and professional.
"""

        with st.spinner("Generating AI Recommendation..."):

            response = ollama.chat(
                model="llama3.2",
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

        st.success("Recommendation Generated")

        st.markdown(response["message"]["content"])


#======================= tab 3 AI Insights =========================

# ================== TAB 3 : AI Insights =====================
with tab3:

    st.header("🧠 AI Insights")

    if "job_description" not in st.session_state:
        st.warning("Generate interview questions first.")
        st.stop()

    st.info("Generate personalized AI insights based on the interview evaluation.")

    # -----------------------------
    # Metrics
    # -----------------------------
    col1, col2, col3, col4 = st.columns(4)

    col1.metric("Overall Match", f"{overall}%")
    col2.metric("Technical", f"{technical}/10")
    col3.metric("Communication", f"{communication}/10")
    col4.metric("Confidence", f"{confidence}/10")

    st.divider()

    # -----------------------------
    # Pie Chart
    # -----------------------------
    labels = [
        "Technical",
        "Coding",
        "Problem Solving",
        "Communication",
        "Confidence",
        "Projects",
        "Behavior",
        "Culture"
    ]

    values = [
        technical,
        coding,
        problem,
        communication,
        confidence,
        projects,
        behavior,
        culture
    ]

    fig = px.pie(
        values=values,
        names=labels,
        title="Candidate Performance Distribution",
        hole=0.4
    )

    st.plotly_chart(fig, use_container_width=True)

    st.divider()

    # -----------------------------
    # Generate AI Insights
    # -----------------------------
    if st.button("🧠 Generate AI Insights", use_container_width=True):

        with st.spinner("Analyzing Candidate..."):

            prompt = f"""
You are an experienced HR Manager.

Job Description:
{st.session_state['job_description']}

Interview Scores:

Technical Knowledge: {technical}/10
Coding Skills: {coding}/10
Problem Solving: {problem}/10
Communication: {communication}/10
Confidence: {confidence}/10
Project Explanation: {projects}/10
Behavioral Skills: {behavior}/10
Cultural Fit: {culture}/10

Overall Match: {overall}%

Generate a professional report with the following sections:

## Candidate Summary
(2-3 lines)

## Job Match Analysis

## Top Strengths
- Bullet Points

## Areas for Improvement
- Bullet Points

## Suggested Learning Resources

## Career Potential

## Recommended Next Interview Round

## Final HR Insights

Keep the report professional and under 500 words.
"""

            response = ollama.chat(
                model="llama3.2",
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

        st.success("✅ AI Insights Generated Successfully!")

        st.markdown(response["message"]["content"])
