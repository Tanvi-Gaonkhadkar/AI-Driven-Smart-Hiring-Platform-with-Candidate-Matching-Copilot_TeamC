import streamlit as st
import pandas as pd
import json
from datetime import datetime
from pathlib import Path
import ollama
import time

# Import utility functions
from utils.candidate_analyser import SKILLS, extract_candidate_info

st.set_page_config(page_title="HR ChatBot AI Pro", layout="wide", initial_sidebar_state="expanded")

# Custom CSS for chat interface
st.markdown("""
<style>
.chat-message {
    display: flex;
    margin: 10px 0;
    padding: 10px;
    border-radius: 8px;
}
.user-message {
    background-color: #e3f2fd;
    justify-content: flex-end;
    margin-left: 10%;
}
.bot-message {
    background-color: #f5f5f5;
    justify-content: flex-start;
    margin-right: 10%;
}
.message-text {
    padding: 12px 15px;
    border-radius: 8px;
    max-width: 100%;
    line-height: 1.5;
}
.user-text {
    background-color: #1976d2;
    color: white;
    border-radius: 18px 18px 2px 18px;
}
.bot-text {
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 18px 18px 18px 2px;
}
.status-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: bold;
}
.ai-badge {
    background-color: #c8e6c9;
    color: #2e7d32;
}
</style>
""", unsafe_allow_html=True)

# ==================== Load Data ====================
DATA_DIR = Path(".")

@st.cache_data
def load_csv(path: Path) -> pd.DataFrame:
    try:
        df = pd.read_csv(path)
        df.columns = df.columns.str.lower()
        return df
    except FileNotFoundError:
        return pd.DataFrame()
    except Exception as e:
        st.warning(f"Could not load {path}")
        return pd.DataFrame()

candidate_df = load_csv(DATA_DIR / "Candidates.csv")
job_df = load_csv(DATA_DIR / "job.csv")
employee_df = load_csv(DATA_DIR / "employee_details.csv")

# ==================== Initialize Session State ====================
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "context" not in st.session_state:
    st.session_state.context = {
        "total_candidates": len(candidate_df),
        "total_jobs": len(job_df),
        "total_employees": len(employee_df),
        "candidates_by_status": candidate_df["status"].value_counts().to_dict() if not candidate_df.empty else {},
        "jobs_by_status": job_df["status"].value_counts().to_dict() if not job_df.empty else {},
    }

if "llm_enabled" not in st.session_state:
    st.session_state.llm_enabled = False

# ==================== Check LLM Availability ====================
@st.cache_resource
def check_llm_availability():
    """Check if Ollama and llama3.2 are available"""
    try:
        response = ollama.list()
        models = [m.get('name', '').split(':')[0] for m in response.get('models', [])]
        return "llama3.2" in models or "llama2" in models or any("llama" in m for m in models)
    except:
        return False

llm_available = check_llm_availability()

# ==================== Generate HR Context ====================
def get_hr_context():
    """Build a comprehensive HR context for the LLM"""
    context = f"""
You are an expert HR and recruitment advisor. You have access to the following organizational data:

**Organization Overview:**
- Total Candidates in Pipeline: {st.session_state.context['total_candidates']}
- Open Job Positions: {st.session_state.context['total_jobs']}
- Current Employees: {st.session_state.context['total_employees']}

**Candidate Status Distribution:**
{json.dumps(st.session_state.context['candidates_by_status'], indent=2)}

**Job Status Distribution:**
{json.dumps(st.session_state.context['jobs_by_status'], indent=2)}

**In-Demand Skills:**
{', '.join(SKILLS[:20])}

**Your Expertise Areas:**
1. Recruitment & Hiring Strategy
2. Candidate Assessment & Matching
3. Salary & Compensation Analysis
4. Talent Development & Training
5. Performance Management
6. Retention Strategies
7. HR Analytics & Metrics
8. Employment Regulations

Always provide actionable, data-driven recommendations tailored to HR and recruitment context.
When discussing candidates or positions, reference the available data.
Focus on practical solutions that can be implemented immediately.
"""
    return context

# ==================== LLM-Powered Response Generation ====================
def generate_llm_response(user_input: str, chat_history: list) -> str:
    """Generate response using Ollama LLM"""
    try:
        # Prepare conversation history for LLM
        messages = [{"role": "system", "content": get_hr_context()}]
        
        # Add recent chat history (last 5 exchanges for context)
        for msg in st.session_state.chat_history[-10:]:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # Add current user input
        messages.append({"role": "user", "content": user_input})
        
        # Get response from Ollama
        response = ollama.chat(
            model="llama3.2",
            messages=messages,
            stream=False,
            options={"temperature": 0.7}
        )
        
        return response["message"]["content"]
    
    except Exception as e:
        return f"""I encountered an issue accessing the AI model. Please ensure Ollama is running.

Error: {str(e)}

However, I can still help you! Ask me about:
• Recruitment insights
• Candidate analysis
• Hiring recommendations
• Talent management strategies"""

# ==================== Fallback Response Generation ====================
def get_hiring_insights():
    """Generate insights about current hiring status"""
    insights = []
    
    if not job_df.empty:
        open_jobs = len(job_df)
        insights.append(f"📋 **Current Job Openings:** {open_jobs} positions")
        
        if "job_title" in job_df.columns:
            top_jobs = job_df["job_title"].value_counts().head(3)
            insights.append(f"\n**Top In-Demand Roles:**")
            for job, count in top_jobs.items():
                insights.append(f"  • {job}: {count} opening(s)")
    
    if not candidate_df.empty:
        insights.append(f"\n👥 **Total Candidates:** {len(candidate_df)}")
        if "status" in candidate_df.columns:
            status_dist = candidate_df["status"].value_counts()
            insights.append("\n**Candidate Status:**")
            for status, count in status_dist.items():
                insights.append(f"  • {status}: {count}")
    
    return "\n".join(insights) if insights else "No hiring data available."

def get_candidate_insights():
    """Generate insights about candidates"""
    if candidate_df.empty:
        return "No candidate data available."
    
    insights = [f"👥 **Total Candidates:** {len(candidate_df)}"]
    
    if "education" in candidate_df.columns:
        top_education = candidate_df["education"].value_counts().head(3)
        insights.append("\n**Top Qualifications:**")
        for edu, count in top_education.items():
            insights.append(f"  • {edu}: {count}")
    
    return "\n".join(insights)

def get_quick_recommendation(topic: str) -> str:
    """Get quick recommendations without LLM"""
    recommendations = {
        "hiring": "Focus on finding candidates with the right skill match. Use our JD & Resume Matching tool to identify the best fits.",
        "candidates": "Review candidate profiles thoroughly. Use our Resume Chat tool for detailed analysis.",
        "training": "Identify skill gaps first. Our Talent Insights tool can help analyze what training is needed.",
        "retention": "Focus on career growth opportunities, competitive compensation, and regular feedback.",
        "analytics": "Track time-to-hire, quality-of-hire, and candidate satisfaction for better metrics."
    }
    return recommendations.get(topic, "I'm here to help! Ask me a specific question about recruitment or talent management.")

# ==================== UI Layout ====================
st.title("🤖 HR ChatBot AI - Pro Edition")
st.markdown("*Powered by Local AI (Ollama) + Real HR Data*")

# Status bar
status_col1, status_col2, status_col3 = st.columns(3)

with status_col1:
    if llm_available:
        st.success("✅ AI Model Ready (llama3.2)")
    else:
        st.warning("⚠️ AI Model Not Available - Using Standard Responses")

with status_col2:
    st.info(f"📊 Data: {st.session_state.context['total_candidates']} candidates | {st.session_state.context['total_jobs']} jobs")

with status_col3:
    messages_count = len([m for m in st.session_state.chat_history if m["role"] == "user"])
    st.info(f"💬 {messages_count} questions asked")

st.markdown("---")

# Create two columns: Chat and Info
col1, col2 = st.columns([3, 1])

with col1:
    st.subheader("💬 Chat with AI HR Assistant")
    
    # Display chat history
    chat_container = st.container(border=True, height=450)
    
    with chat_container:
        if not st.session_state.chat_history:
            st.info("👋 Welcome! Ask me anything about recruitment, candidates, hiring, talent management, or HR best practices.")
        else:
            for i, message in enumerate(st.session_state.chat_history):
                if message["role"] == "user":
                    st.markdown(f"""
                    <div class="chat-message user-message">
                        <div class="message-text user-text">
                            {message["content"]}
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class="chat-message bot-message">
                        <div class="message-text bot-text">
                            {message["content"]}
                            <br><span class="status-badge ai-badge">AI Response</span>
                        </div>
                    </div>
                    """, unsafe_allow_html=True)
    
    # Input area
    st.markdown("---")
    
    col_input, col_send = st.columns([4, 1])
    with col_input:
        user_input = st.text_input(
            "You:",
            placeholder="Ask me anything about recruitment, hiring, candidates, training, analytics...",
            key="user_input",
            label_visibility="collapsed"
        )
    
    with col_send:
        if st.button("Send ➤", use_container_width=True, type="primary"):
            if user_input.strip():
                # Add user message
                st.session_state.chat_history.append({
                    "role": "user",
                    "content": user_input,
                    "timestamp": datetime.now()
                })
                
                # Generate bot response
                with st.spinner("🤖 Thinking..."):
                    if llm_available:
                        bot_response = generate_llm_response(user_input, st.session_state.chat_history)
                    else:
                        # Fallback to simple responses
                        if any(word in user_input.lower() for word in ["hiring", "recruit", "candidate", "job"]):
                            bot_response = get_hiring_insights()
                        elif any(word in user_input.lower() for word in ["candidate", "applicant", "profile"]):
                            bot_response = get_candidate_insights()
                        else:
                            bot_response = get_quick_recommendation("general")
                
                st.session_state.chat_history.append({
                    "role": "bot",
                    "content": bot_response,
                    "timestamp": datetime.now()
                })
                
                st.rerun()

with col2:
    st.subheader("ℹ️ Quick Actions")
    
    # Display context information
    with st.container(border=True):
        st.markdown("**📊 Data Summary**")
        st.metric("👥 Candidates", st.session_state.context['total_candidates'])
        st.metric("💼 Jobs", st.session_state.context['total_jobs'])
        st.metric("👔 Employees", st.session_state.context['total_employees'])
        
        st.markdown("---")
        st.markdown("**🎯 Suggested Questions**")
        
        questions = [
            ("Show hiring status", "👔"),
            ("Candidate insights", "👥"),
            ("Analytics metrics", "📊"),
            ("Training recommendations", "🎓"),
            ("Retention strategies", "💡"),
            ("Salary insights", "💰"),
        ]
        
        for question, emoji in questions:
            if st.button(f"{emoji} {question}", use_container_width=True, key=f"btn_{question}"):
                st.session_state.chat_history.append({"role": "user", "content": question})
                with st.spinner("🤖 Processing..."):
                    if llm_available:
                        response = generate_llm_response(question, st.session_state.chat_history)
                    else:
                        if "hiring" in question.lower():
                            response = get_hiring_insights()
                        else:
                            response = get_quick_recommendation(question.lower())
                
                st.session_state.chat_history.append({"role": "bot", "content": response})
                st.rerun()

# ==================== Footer ====================
st.markdown("---")

footer_col1, footer_col2, footer_col3 = st.columns(3)

with footer_col1:
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.chat_history = []
        st.rerun()

with footer_col2:
    if st.button("📥 Export Chat", use_container_width=True):
        if st.session_state.chat_history:
            chat_json = json.dumps([
                {**msg, "timestamp": msg["timestamp"].isoformat() if isinstance(msg.get("timestamp"), datetime) else str(msg.get("timestamp", ""))}
                for msg in st.session_state.chat_history
            ], indent=2)
            st.download_button(
                label="Download JSON",
                data=chat_json,
                file_name=f"chat_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json",
                use_container_width=True
            )

with footer_col3:
    st.caption("💡 Tip: Be specific for better AI insights!")

# ==================== Info Section ====================
with st.expander("ℹ️ About This ChatBot"):
    st.markdown("""
    ### 🤖 HR ChatBot Features:
    
    **AI-Powered Responses:**
    - Uses local Ollama LLM (llama3.2) for intelligent, context-aware answers
    - Integrated with your organizational data
    
    **Expertise Areas:**
    - 📋 Recruitment & Hiring Strategy
    - 👥 Candidate Assessment & Matching
    - 💰 Salary & Compensation Analysis
    - 🎓 Talent Development & Training
    - ⭐ Performance Management
    - 📊 HR Analytics & Metrics
    
    **How to Get Best Results:**
    1. Ask specific questions about recruitment or HR
    2. Reference job titles, skills, or departments
    3. Ask for recommendations based on scenarios
    4. Request analysis of your current data
    
    **Example Questions:**
    - "What's our hiring pipeline look like?"
    - "Recommend candidates for a senior developer role"
    - "What training programs should we implement?"
    - "How can we improve retention?"
    - "Analyze our candidate skill distribution"
    """)

st.markdown("""
---
**🚀 HR ChatBot Pro** | AI-Powered Recruitment Assistant | Streamlit Edition
""")
