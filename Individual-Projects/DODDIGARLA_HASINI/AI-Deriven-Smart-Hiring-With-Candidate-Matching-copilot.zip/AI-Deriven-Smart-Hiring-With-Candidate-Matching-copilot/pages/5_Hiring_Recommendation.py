import streamlit as st

st.title("🤖 Hiring Recommendation AI")

from login import require_login
require_login()


# Remaining imports...

import streamlit as st
import ollama
from utils.resume_parser import extract_resume_text



st.markdown("Generate the final hiring recommendation based on the candidate's resume and job description.")

uploaded_resume = st.file_uploader(
    "Upload Candidate Resume",
    type=["pdf", "docx", "txt"]
)

job_description = st.text_area(
    "Paste Job Description",
    height=220
)

resume_match = st.slider(
    "Resume Match Score (%)",
    0,
    100,
    80
)

interview_feedback = st.text_area(
    "Interview Feedback",
    height=120,
    placeholder="Enter interviewer's observations..."
)

hr_notes = st.text_area(
    "HR Notes (Optional)",
    height=120
)

if uploaded_resume is not None:

    resume_text = extract_resume_text(uploaded_resume)

    st.divider()

    st.subheader("📊 Candidate Overview")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            "Resume Match",
            f"{resume_match}%"
        )

    with col2:

        if resume_match >= 85:
            status = "Excellent"

        elif resume_match >= 70:
            status = "Good"

        else:
            status = "Average"

        st.metric(
            "Profile Status",
            status
        )

    with col3:

        if resume_match >= 80:
            fit = "High"

        elif resume_match >= 60:
            fit = "Medium"

        else:
            fit = "Low"

        st.metric(
            "Job Fit",
            fit
        )

    st.progress(resume_match/100)

if st.button("🤖 Generate Hiring Recommendation", use_container_width=True):

    if uploaded_resume is None:
        st.warning("Please upload a resume.")
        st.stop()

    if not job_description.strip():
        st.warning("Please enter the Job Description.")
        st.stop()

    resume_text = extract_resume_text(uploaded_resume)

    prompt = f"""
You are an experienced HR Director.

Candidate Resume:

{resume_text}

Job Description:

{job_description}

Resume Match Score:
{resume_match}%

Interview Feedback:

{interview_feedback}

HR Notes:

{hr_notes}

Generate a professional hiring report with the following sections.

# Candidate Summary

# Skills Match Analysis

# Key Strengths

# Areas for Improvement

# Potential Risks

# Final Hiring Decision

Choose ONLY one:

• Hire Immediately
• Strong Hire
• Hire
• Hold
• Reject

# Justification

# Suggested Next Steps

Keep the report professional and under 400 words.
"""

    with st.spinner("Generating Recommendation..."):

        response = ollama.chat(
            model="llama3.2",
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

    st.success("✅ Hiring Recommendation Generated")

    st.markdown(response["message"]["content"])