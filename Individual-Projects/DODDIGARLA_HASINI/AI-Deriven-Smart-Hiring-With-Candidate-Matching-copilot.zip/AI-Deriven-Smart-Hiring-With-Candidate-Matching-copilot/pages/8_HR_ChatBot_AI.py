"""
=========================================================
🤖 AI Recruitment & Talent Management Chatbot
Part 1 - UI + Gemini Setup + Chat Interface (FIXED)
=========================================================
Features
✔ Modern ChatGPT UI
✔ Gemini API Integration
✔ Sidebar
✔ Chat Memory
✔ File Upload UI
✔ Chat Controls
✔ Professional Styling
=========================================================
"""


import streamlit as st

st.set_page_config(
    page_title="AI Recruitment Chatbot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

from login import require_login
require_login()

from sidebar import show_sidebar
show_sidebar()

# Remaining imports...
import os
import streamlit as st
import google.generativeai as genai
import pandas as pd
from PyPDF2 import PdfReader
from docx import Document

# --------------------------------------------------------
# PAGE CONFIG
# --------------------------------------------------------


# --------------------------------------------------------
# CUSTOM CSS
# --------------------------------------------------------

st.markdown("""
<style>
.block-container{
    padding-top:1rem;
    padding-bottom:1rem;
}
.stChatMessage{
    border-radius:12px;
}
.main-title{
    text-align:center;
    font-size:38px;
    font-weight:bold;
    color:#2E86C1;
}
.sub-title{
    text-align:center;
    color:gray;
    margin-bottom:20px;
}
.upload-box{
    padding:15px;
    border-radius:10px;
    background:#F4F6F6;
}
</style>
""", unsafe_allow_html=True)

# --------------------------------------------------------
# TITLE
# --------------------------------------------------------

st.markdown(
    "<h1 class='main-title'>🤖 AI Recruitment Assistant</h1>",
    unsafe_allow_html=True
)

st.markdown(
    "<p class='sub-title'>Upload resumes, HR documents, CSV files and ask anything about recruitment.</p>",
    unsafe_allow_html=True
)

def is_recruitment_question(question):
    keywords = [
        'resume', 'cv', 'candidate', 'recruit', 'recruitment',
        'hiring', 'hire', 'employee', 'interview',
        'job', 'job description', 'jd', 'ats',
        'talent', 'skill', 'screening', 'training',
        'hr', 'human resource', 'career',
        'onboarding', 'offer letter', 'performance'
    ]

    q = question.lower()
    return any(word in q for word in keywords)

# --------------------------------------------------------
# GEMINI API
# (reads from .streamlit/secrets.toml -> GEMINI_API_KEY = "...")
# --------------------------------------------------------

API_KEY = st.secrets.get("GEMINI_API_KEY", os.getenv("GEMINI_API_KEY"))

if not API_KEY:
    st.error("GEMINI_API_KEY is missing. Add it to .streamlit/secrets.toml.")
    st.stop()

genai.configure(api_key=API_KEY)
model = genai.GenerativeModel("gemini-2.5-flash")

# --------------------------------------------------------
# SESSION STATE
# --------------------------------------------------------

if "messages" not in st.session_state:
    st.session_state.messages = []

if "document_text" not in st.session_state:
    st.session_state.document_text = ""

if "file_names" not in st.session_state:
    st.session_state.file_names = []

if "file_count" not in st.session_state:
    st.session_state.file_count = 0

# --------------------------------------------------------
# FILE READERS
# --------------------------------------------------------

def read_txt(file):
    try:
        return file.read().decode("utf-8")
    except Exception:
        return ""

def read_pdf(file):
    text = ""
    reader = PdfReader(file)
    for page in reader.pages:
        extracted = page.extract_text()
        if extracted:
            text += extracted + "\n"
    return text

def read_docx(file):
    text = ""
    document = Document(file)
    for paragraph in document.paragraphs:
        text += paragraph.text + "\n"
    return text

def read_csv(file):
    try:
        df = pd.read_csv(file)
        return df.to_string(index=False)
    except Exception:
        return ""

def read_excel(file):
    try:
        df = pd.read_excel(file)
        return df.to_string(index=False)
    except Exception:
        return ""

def extract_file_text(uploaded_file):
    extension = uploaded_file.name.split(".")[-1].lower()

    if extension == "txt":
        return read_txt(uploaded_file)
    elif extension == "pdf":
        return read_pdf(uploaded_file)
    elif extension == "docx":
        return read_docx(uploaded_file)
    elif extension == "csv":
        return read_csv(uploaded_file)
    elif extension == "xlsx":
        return read_excel(uploaded_file)
    else:
        return ""

# --------------------------------------------------------
# TASK DETECTION
# --------------------------------------------------------

def detect_task(question):
    q = question.lower()

    if "resume" in q:
        return "resume"
    elif "candidate" in q:
        return "candidate"
    elif "training" in q:
        return "training"
    elif "employee" in q:
        return "employee"
    elif "interview" in q:
        return "interview"
    elif "job description" in q:
        return "job"
    else:
        return "general"

# --------------------------------------------------------
# CHAT HISTORY / DOCUMENT CONTEXT HELPERS
# --------------------------------------------------------

def build_chat_history():
    history = ""
    for msg in st.session_state.messages:
        role = msg["role"].capitalize()
        history += f"{role}: {msg['content']}\n"
    return history

def get_document_context():
    if len(st.session_state.document_text.strip()) == 0:
        return "No uploaded documents."
    return st.session_state.document_text

# --------------------------------------------------------
# PROMPT BUILDER  (fixed: takes `question`, initializes `prompt`,
# and actually returns a complete string)
# --------------------------------------------------------

def create_prompt(question):
    task = detect_task(question)

    prompt = f'''
You are an AI Recruitment & Talent Management Assistant.

YOUR ROLE
---------
You are a domain-specific AI assistant that ONLY answers questions related to recruitment and talent management.

You can help with:
- Resume analysis
- Candidate screening
- Candidate ranking
- Interview question generation
- Job description analysis
- ATS evaluation
- Hiring recommendations
- Recruitment strategy
- Talent management
- Employee training and upskilling
- HR recruitment processes
- Skills gap analysis
- Candidate comparison
- Career guidance related to recruitment and hiring

IMPORTANT RULE
--------------
If the user asks anything NOT related to recruitment, hiring, HR, resumes, interviews, candidates, employees, job descriptions, talent management, or career recruitment:

DO NOT answer the question.

Instead reply EXACTLY with this message:

"I'm an AI Recruitment & Talent Management Assistant, so I can only help with recruitment and HR-related topics. Your question appears to be outside my area of expertise. Please ask me something related to resumes, interviews, hiring, candidate evaluation, job descriptions, recruitment, or talent management."

Never answer unrelated questions.
Never provide general knowledge.
Never switch topics.
Never continue the unrelated conversation.

============================
CURRENT TASK
============================
{task}

============================
UPLOADED DOCUMENTS
============================
{get_document_context()}

============================
CHAT HISTORY
============================
{build_chat_history()}

============================
USER QUESTION
============================
{question}

============================
INSTRUCTIONS
============================
1. First check whether the question is related to recruitment or talent management.
2. If it is unrelated, return ONLY the exact refusal message above.
3. If it is related, answer professionally and clearly.
4. Use uploaded documents when relevant.
5. Use chat history for context.
6. If analyzing a resume, include:
   - Skills
   - Experience
   - Education
   - Certifications
   - Projects
   - ATS score
   - Missing skills
   - Hiring recommendation
7. If generating interview questions, categorize them by difficulty and type.
8. Use bullet points whenever helpful.
9. Keep the response professional and concise.
'''

    return prompt
# --------------------------------------------------------
# SIDEBAR
# --------------------------------------------------------

with st.sidebar:
    st.title("⚙ Chat Settings")
    st.divider()

    if st.button("🗑 Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.session_state.document_text = ""
        st.session_state.file_names = []
        st.session_state.file_count = 0
        st.rerun()

# --------------------------------------------------------
# RENDER PAST CHAT MESSAGES
# --------------------------------------------------------

for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# --------------------------------------------------------
# CHAT INPUT
# (accept_file=True adds a "+" attach icon inside the box,
#  ChatGPT/Claude style — no separate uploader needed)
# --------------------------------------------------------

user_input = st.chat_input(
    "Ask anything about recruitment, HR, hiring, interviews...",
    accept_file=True,
    file_type=["pdf", "docx", "txt", "csv", "xlsx"]
)

if user_input:
    question = user_input.text
    attached_files = user_input.files

    # Process uploaded files
    if attached_files:
        all_text = st.session_state.document_text
        new_names = []

        for file in attached_files:
            new_names.append(file.name)
            extracted_text = extract_file_text(file)

            if extracted_text:
                all_text += f"\n\n===== {file.name} =====\n\n"
                all_text += extracted_text

        st.session_state.document_text = all_text
        st.session_state.file_names.extend(new_names)
        st.session_state.file_count = len(st.session_state.file_names)

    if not question:
        question = "Please analyze the attached file(s)."

    st.session_state.messages.append(
        {"role": "user", "content": question}
    )

    with st.chat_message("user"):
        if attached_files:
            st.caption("📎 " + ", ".join(f.name for f in attached_files))
        st.markdown(question)

    with st.chat_message("assistant"):
        with st.spinner("🤖 Thinking..."):

            # File-only analysis
            if attached_files and question == "Please analyze the attached file(s).":

                prompt = create_prompt(question)

                try:
                    response = model.generate_content(prompt)
                    answer = response.text

                except Exception as e:
                    answer = f"❌ Error\n\n{e}"

            # Block unrelated questions
            elif not is_recruitment_question(question):

                answer = (
                    "🚫 **Out of Scope**\n\n"
                    "I'm an AI Recruitment & Talent Management Assistant.\n\n"
                    "I can only help with:\n\n"
                    "• Resume Analysis\n"
                    "• Candidate Screening\n"
                    "• Interview Preparation\n"
                    "• Job Description Analysis\n"
                    "• Hiring Recommendations\n"
                    "• Talent Management\n"
                    "• Employee Training\n"
                    "• ATS Evaluation\n\n"
                    "Please ask a recruitment or HR-related question."
                )

            # Valid recruitment question
            else:

                prompt = create_prompt(question)

                try:
                    response = model.generate_content(prompt)
                    answer = response.text

                except Exception as e:
                    answer = f"""
❌ Error

{e}

Possible reasons:
• Invalid Gemini API Key
• Internet connection
• API quota exceeded
• Gemini temporarily unavailable
"""

        st.markdown(answer)

    st.session_state.messages.append(
        {"role": "assistant", "content": answer}
    )