import streamlit as st

st.set_page_config(
    page_title="Resume Chat & Candidate Comparison",
    layout="wide"
)
from login import require_login
require_login()

from sidebar import show_sidebar
show_sidebar()

# Remaining imports...
import streamlit as st
from utils.resume_parser import extract_resume_text
from sidebar import show_sidebar
import ollama

# -----------------------------
# Page Configuration
# -----------------------------

# Hide Streamlit navigation
st.markdown("""
<style>
[data-testid="stSidebarNav"] {
    display: none;
}
</style>
""", unsafe_allow_html=True)

st.title("🗂️ Resume Chat & Candidate Comparison AI")

tab1, tab2 = st.tabs([
    "💬 Resume Chat",
    "👥 Candidate Comparison",
    
])

# ====================================================
# TAB 1 : Resume Chat AI
# ====================================================

with tab1:

    st.header("💬 Resume Chat AI")

    uploaded_resume = st.file_uploader(
        "Upload Candidate Resume",
        type=["pdf", "docx", "txt"]
    )

    if uploaded_resume:

        resume_text = extract_resume_text(uploaded_resume)

        st.success("Resume Uploaded Successfully")

        question = st.text_input(
            "Ask anything about the candidate"
        )

        if st.button("Ask AI"):

            prompt = f"""
You are an HR Resume Assistant.

Resume:

{resume_text}

Answer ONLY from the resume.

Question:

{question}

If the answer is unavailable, say
'Not mentioned in the resume.'
"""

            with st.spinner("Analyzing Resume..."):

                response = ollama.chat(
                    model="llama3.2",
                    messages=[
                        {
                            "role":"user",
                            "content":prompt
                        }
                    ]
                )

            st.markdown(response["message"]["content"])


# ====================================================
# TAB 2 : Candidate Comparison AI
# ====================================================

with tab2:

    st.header("👥 Candidate Comparison AI")

    # Upload multiple resumes
    uploaded_resumes = st.file_uploader(
        "Upload Candidate Resumes",
        type=["pdf", "docx", "txt"],
        accept_multiple_files=True
    )

    # Job Description
    job_description = st.text_area(
        "Paste Job Description",
        height=200
    )

    # Select candidates
    if uploaded_resumes:

        resume_names = [resume.name for resume in uploaded_resumes]

        selected_candidates = st.multiselect(
            "Select Candidates to Compare",
            options=resume_names,
            default=resume_names[:2]
        )

    else:
        selected_candidates = []

    # Compare Button
    if st.button("Compare Candidates"):

        if len(uploaded_resumes) < 2:
            st.warning("⚠ Please upload at least two resumes.")

        elif len(selected_candidates) < 2:
            st.warning("⚠ Please select at least two candidates.")

        elif not job_description.strip():
            st.warning("⚠ Please enter the Job Description.")

        else:

            selected_resume_texts = {}

            for resume in uploaded_resumes:

                if resume.name in selected_candidates:

                    selected_resume_texts[resume.name] = extract_resume_text(resume)

            st.session_state["selected_resumes"] = selected_resume_texts
            st.session_state["jd"] = job_description

            st.success(f"✅ {len(selected_candidates)} candidates selected successfully.")

    # Generate AI Comparison
    if "selected_resumes" in st.session_state:

        if st.button("🤖 Generate AI Comparison"):

            resume_content = ""

            for name, text in st.session_state["selected_resumes"].items():

                resume_content += f"""

Candidate Name: {name}

Resume:
{text}

--------------------------------------------------------

"""

            prompt = f"""
You are a Senior HR Manager.

Job Description:

{st.session_state['jd']}

Below are the shortlisted candidates.

{resume_content}

Compare all candidates and generate a professional report.

Include:

1. Candidate-wise Summary

2. Technical Skills Comparison

3. Experience Comparison

4. Project Comparison

5. Education Comparison

6. Strengths of Each Candidate

7. Weaknesses of Each Candidate

8. Rank the Candidates from Best to Least Suitable

9. Identify the Best Candidate

10. Explain why the selected candidate is the best fit.

11. Final Hiring Recommendation

Present the comparison in a clean and professional format.
"""

            with st.spinner("Comparing Candidates..."):

                response = ollama.chat(
                    model="llama3.2",
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                )

            st.success("✅ Candidate Comparison Completed")

            st.markdown(response["message"]["content"])