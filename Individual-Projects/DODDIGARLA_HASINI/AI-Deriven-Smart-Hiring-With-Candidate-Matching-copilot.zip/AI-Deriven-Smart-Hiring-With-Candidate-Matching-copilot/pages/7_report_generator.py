import streamlit as st

st.set_page_config(
    page_title="AI Report Generator",
    page_icon="📑",
    layout="wide"
)

from login import require_login
require_login()


# Remaining imports...

import streamlit as st
import pandas as pd
import ollama

from sidebar import show_sidebar

# -------------------------------------------------------
# Page Config
# -------------------------------------------------------


show_sidebar()

st.markdown("""
<style>
[data-testid="stSidebarNav"]{
display:none;
}
</style>
""", unsafe_allow_html=True)

st.title("📑 AI Recruitment Report Generator")

st.markdown(
"""
Generate intelligent recruitment analytics and AI-powered recruitment reports.
"""
)

# -------------------------------------------------------
# Load CSV Files
# -------------------------------------------------------

try:

    candidates = pd.read_csv("Candidates.csv")

    jobs = pd.read_csv("job.csv")

    employees = pd.read_csv("employee_details.csv")

except Exception as e:

    st.error(e)

    st.stop()

# -------------------------------------------------------
# Candidate Statistics
# -------------------------------------------------------

total_candidates = len(candidates)

selected = len(
    candidates[
        candidates["Status"].str.lower() == "selected"
    ]
)

shortlisted = len(
    candidates[
        candidates["Status"].str.lower() == "shortlisted"
    ]
)

rejected = len(
    candidates[
        candidates["Status"].str.lower() == "rejected"
    ]
)

pending = total_candidates - (
    selected +
    shortlisted +
    rejected
)

avg_experience = round(
    pd.to_numeric(candidates["experience"], errors="coerce").mean(),
    1
)

# Resume Score

if "Resume_Score" in candidates.columns:

    avg_resume_score = round(
        pd.to_numeric(candidates["Resume_Score"], errors="coerce").mean(),
        2
    )

else:

    avg_resume_score = "N/A"

# -------------------------------------------------------
# Job Statistics
# -------------------------------------------------------

total_jobs = len(jobs)

active_jobs = len(
    jobs[
        jobs["status"].str.lower() == "active"
    ]
)

closed_jobs = len(
    jobs[
        jobs["status"].str.lower() == "closed"
    ]
)

# -------------------------------------------------------
# Employee Statistics
# -------------------------------------------------------

total_employees = len(employees)

promotion_ready = len(
    employees[
        employees["Promotion_Ready"] == "Yes"
    ]
)

high_attrition = len(
    employees[
        employees["Attrition_Risk"] == "High"
    ]
)

avg_performance = round(
    employees["Performance_Score"].mean(),
    2
)

# -------------------------------------------------------
# Dashboard
# -------------------------------------------------------

st.subheader("📊 Recruitment Dashboard")

c1, c2, c3, c4 = st.columns(4)

c1.metric(
    "Candidates",
    total_candidates
)

c2.metric(
    "Selected",
    selected
)

c3.metric(
    "Shortlisted",
    shortlisted
)

c4.metric(
    "Rejected",
    rejected
)

c5, c6, c7, c8 = st.columns(4)

c5.metric(
    "Jobs",
    total_jobs
)

c6.metric(
    "Employees",
    total_employees
)

c7.metric(
    "Promotion Ready",
    promotion_ready
)

c8.metric(
    "High Attrition",
    high_attrition
)

st.divider()
# -------------------------------------------------------
# Candidate Analytics
# -------------------------------------------------------

st.subheader("👨‍💼 Candidate Analytics")

col1, col2 = st.columns(2)

with col1:

    st.markdown("### Candidate Status Distribution")

    status_counts = candidates["Status"].value_counts()

    st.bar_chart(status_counts)

with col2:

    st.markdown("### Education Distribution")

    education_counts = candidates["education"].value_counts()

    st.bar_chart(education_counts)

st.divider()

# -------------------------------------------------------
# Top Skills
# -------------------------------------------------------

st.subheader("💻 Top Skills")

all_skills = []

for skills in candidates["skills"].dropna():

    skill_list = [s.strip() for s in str(skills).split(",")]

    all_skills.extend(skill_list)

skills_df = (
    pd.Series(all_skills)
    .value_counts()
    .reset_index()
)

skills_df.columns = ["Skill", "Count"]

st.dataframe(
    skills_df,
    use_container_width=True
)

st.bar_chart(
    skills_df.set_index("Skill")
)

st.divider()

# -------------------------------------------------------
# Job Analytics
# -------------------------------------------------------

st.subheader("💼 Job Analytics")

col1, col2 = st.columns(2)

with col1:

    st.markdown("### Department-wise Openings")

    dept = jobs["department"].value_counts()

    st.bar_chart(dept)

with col2:

    st.markdown("### Employment Type")

    employment = jobs["employment_type"].value_counts()

    st.bar_chart(employment)

st.divider()

# -------------------------------------------------------
# Employee Insights
# -------------------------------------------------------

st.subheader("👨‍💼 Employee Insights")

col1, col2 = st.columns(2)

with col1:

    st.markdown("### Performance Score")

    performance = employees["Performance_Score"]

    st.line_chart(performance)

with col2:

    st.markdown("### Promotion Ready")

    promotion = employees["Promotion_Ready"].value_counts()

    st.bar_chart(promotion)

st.divider()

# -------------------------------------------------------
# High Attrition Risk Employees
# -------------------------------------------------------

st.subheader("⚠ High Attrition Risk")

high_risk = employees[
    employees["Attrition_Risk"] == "High"
]

st.dataframe(
    high_risk[
        [
            "Name",
            "Department",
            "Role",
            "Performance_Score",
            "Recommendation"
        ]
    ],
    use_container_width=True
)

st.divider()

# -------------------------------------------------------
# Candidate Table
# -------------------------------------------------------

st.subheader("📄 Candidate Details")

candidate_columns = [
    "name",
    "email",
    "education",
    "experience",
    "skills",
    "Status"
]

if "Resume_Score" in candidates.columns:
    candidate_columns.append("Resume_Score")

st.dataframe(
    candidates[candidate_columns],
    use_container_width=True
)

st.divider()

# -------------------------------------------------------
# Job Table
# -------------------------------------------------------

st.subheader("📌 Job Openings")

st.dataframe(
    jobs[
        [
            "job_title",
            "department",
            "Location",
            "employment_type",
            "experience_required",
            "status"
        ]
    ],
    use_container_width=True
)

st.divider()

# -------------------------------------------------------
# Employee Table
# -------------------------------------------------------

st.subheader("🏢 Employee Details")

st.dataframe(
    employees[
        [
            "Name",
            "Department",
            "Role",
            "Performance_Score",
            "Promotion_Ready",
            "Attrition_Risk"
        ]
    ],
    use_container_width=True
)

st.divider()

# -------------------------------------------------------
# AI Recruitment Report
# -------------------------------------------------------

st.subheader("🤖 AI Recruitment Report")

# Prepare summary statistics
top_skills = ", ".join(skills_df.head(10)["Skill"].tolist())

report_summary = f"""
Recruitment Statistics

Total Candidates: {total_candidates}
Selected Candidates: {selected}
Shortlisted Candidates: {shortlisted}
Rejected Candidates: {rejected}
Pending Candidates: {pending}

Average Experience: {avg_experience}

Average Resume Score: {avg_resume_score}

Total Job Openings: {total_jobs}
Active Jobs: {active_jobs}
Closed Jobs: {closed_jobs}

Total Employees: {total_employees}
Promotion Ready Employees: {promotion_ready}
High Attrition Risk Employees: {high_attrition}

Top Skills:
{top_skills}
"""

st.info(report_summary)

st.divider()

# -------------------------------------------------------
# Generate AI Report
# -------------------------------------------------------

if st.button("🤖 Generate AI Recruitment Report", use_container_width=True):

    with st.spinner("Analyzing recruitment data using AI..."):

        prompt = f"""
You are a Senior HR Analytics Consultant.

Analyze the recruitment statistics below and prepare a professional report.

{report_summary}

Generate a detailed report with the following sections.

1. Executive Summary

2. Candidate Analysis
- Quality of applicants
- Resume performance
- Candidate status distribution

3. Recruitment Performance
- Hiring efficiency
- Job openings
- Department hiring

4. Skill Gap Analysis
- Most common skills
- Missing skills
- Suggestions

5. Employee Insights
- Performance
- Promotion readiness
- Attrition risk

6. Workforce Trends

7. Recommendations
Provide practical recommendations to improve recruitment quality,
employee retention, workforce planning, and hiring efficiency.

Write in a professional HR report style.
"""

        try:

            response = ollama.chat(

                model="llama3.2",

                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]

            )

            report = response["message"]["content"]

            st.session_state["report"] = report

            st.success("✅ AI Report Generated Successfully")

        except Exception as e:

            st.error(e)

# -------------------------------------------------------
# Display Report
# -------------------------------------------------------

if "report" in st.session_state:

    st.divider()

    st.subheader("📑 AI Generated Recruitment Report")

    edited_report = st.text_area(

        "Report",

        value=st.session_state["report"],

        height=600

    )

    st.session_state["report"] = edited_report

    st.download_button(

        label="📥 Download AI Report",

        data=edited_report,

        file_name="AI_Recruitment_Report.txt",

        mime="text/plain"

    )

st.divider()

# -------------------------------------------------------
# Report Footer
# -------------------------------------------------------

st.success("✔ Recruitment Analytics Completed Successfully")

st.caption(
    "Generated using Streamlit + Ollama (Llama 3.2)"
)