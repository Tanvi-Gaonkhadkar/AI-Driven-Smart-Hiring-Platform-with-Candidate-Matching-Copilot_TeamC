import streamlit as st
import pandas as pd
import ollama
from sidebar import show_sidebar
import email_utils

# -----------------------------
# Page Config
# -----------------------------
st.set_page_config(
    page_title="AI Email Generator",
    page_icon="📧",
    layout="wide"
)

show_sidebar()

# Hide Streamlit default navigation
st.markdown("""
<style>
[data-testid="stSidebarNav"]{
display:none;
}
</style>
""", unsafe_allow_html=True)

st.title("📧 AI Email Generator")
st.markdown("Generate professional AI-powered emails for candidates and employees.")

# -----------------------------
# Load Candidate and Employee Data
# -----------------------------
candidates_df = None
employees_df = None

try:
    candidates_df = pd.read_csv("Candidates.csv")
except FileNotFoundError:
    st.warning("⚠️ Candidates.csv not found.")

try:
    employees_df = pd.read_csv("employee_details.csv")
except FileNotFoundError:
    st.warning("⚠️ employee_details.csv not found.")

if candidates_df is None and employees_df is None:
    st.error("❌ No candidate or employee data found.")
    st.stop()

# Standardize column names
if candidates_df is not None:
    candidates_df.columns = candidates_df.columns.str.lower().str.strip()
    candidates_df = candidates_df.rename(columns={
        'status': 'status',
        'name': 'name',
        'email': 'email'
    })

if employees_df is not None:
    employees_df.columns = employees_df.columns.str.lower().str.strip()
    employees_df = employees_df.rename(columns={
        'name': 'name',
        'recommendation': 'status'
    })
    if 'email' not in employees_df.columns:
        employees_df['email'] = employees_df['name'].str.lower().str.replace(' ', '.') + '@company.com'

# Get available statuses from data
candidate_statuses = set()
employee_statuses = set()

if candidates_df is not None:
    candidate_statuses = set(candidates_df['status'].str.strip().str.lower().unique())

if employees_df is not None:
    employee_statuses = set(employees_df['status'].str.strip().str.lower().unique())

# -----------------------------
# Person Type Selection
# -----------------------------
person_type = st.radio(
    "👤 Select Type",
    ["Candidate", "Employee"],
    horizontal=True
)

# Determine available email types based on selection
if person_type == "Candidate":
    available_statuses = {
        "Applied": ["Application Acknowledgement"],
        "Interview": ["Interview Invitation", "Interview Reminder"],
        "Shortlisted": ["Shortlisted Notification"],
        "Rejected": ["Rejection Notice"],
        "Hired": ["Offer Letter", "Joining Instructions"]
    }
else:
    available_statuses = {
        "Retain": ["Retention Letter", "Performance Recognition"],
        "Promoted": ["Promotion Letter", "Congratulations"],
        "Performance Improvement": ["Performance Improvement Plan", "Guidance Letter"],
        "Fired": ["Termination Letter", "Final Settlement"]
    }

# Get email type options for selected status
email_types_flat = []
for status, emails in available_statuses.items():
    email_types_flat.extend(emails)

email_type = st.selectbox(
    "📨 Select Email Type",
    email_types_flat
)

# Find the status for the selected email type
required_status = None
for status, emails in available_statuses.items():
    if email_type in emails:
        required_status = status
        break

# Determine which dataframe to use
if person_type == "Candidate":
    data_df = candidates_df.copy() if candidates_df is not None else pd.DataFrame()
else:
    data_df = employees_df.copy() if employees_df is not None else pd.DataFrame()

if data_df.empty:
    st.error(f"❌ No {person_type.lower()} data available.")
    st.stop()

# Verify Required Columns
required_columns = ["name", "email", "status"]
missing = [col for col in required_columns if col not in data_df.columns]

if missing:
    st.error(f"Missing columns: {missing}")
    st.stop()

# Filter by status
if required_status:
    filtered_df = data_df[
        data_df["status"].str.strip().str.lower()
        == required_status.lower()
    ]
else:
    filtered_df = data_df

# -----------------------------
# Show Statistics
# -----------------------------
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Total", len(data_df))

with col2:
    st.metric("Matching", len(filtered_df))

with col3:
    st.metric(f"Type", person_type)

with col4:
    st.metric("Email Type", email_type)

st.divider()

# Display Status Breakdown
with st.expander("📊 View Status Breakdown"):
    status_count = data_df["status"].str.strip().str.lower().value_counts()
    st.bar_chart(status_count)

# -----------------------------
# Candidate Selection
# -----------------------------
st.subheader("👥 Select Recipients")

select_all = st.checkbox("Select All", value=True)

recipient_names = filtered_df["name"].tolist()

if select_all:
    selected_recipients = st.multiselect(
        "Recipients",
        recipient_names,
        default=recipient_names
    )
else:
    selected_recipients = st.multiselect(
        "Recipients",
        recipient_names
    )

# -----------------------------
# Display Selected Candidates
# -----------------------------
if selected_recipients:

    selected_df = filtered_df[
        filtered_df["name"].isin(selected_recipients)
    ]

    st.subheader("Selected Recipients")

    st.dataframe(
        selected_df[
            [
                "name",
                "email",
                "status"
            ]
        ],
        use_container_width=True
    )

else:
    st.warning("Please select at least one recipient.")

st.divider()

# -----------------------------
# Additional Details
# -----------------------------

st.subheader("📝 Email Details")

role = st.text_input(
    "Position/Role (Optional)",
    placeholder="Software Engineer"
)

interview_date = st.date_input(
    "Interview Date (Optional)",
    value=None
)

company = st.text_input(
    "Company Name",
    placeholder="Your Company Name"
)

additional_details = st.text_area(
    "Additional Instructions",
    height=180,
    placeholder="Any specific details, meeting links, contact information, etc."
)

# -----------------------------
# Generate Email
# -----------------------------
st.divider()
st.subheader("🤖 AI Email Generator")

generate = st.button("✨ Generate Email", use_container_width=True)

if generate:

    if len(selected_recipients) == 0:
        st.warning("Please select at least one recipient.")

    else:

        with st.spinner("Generating professional email using AI..."):

            prompt = f"""
You are a professional HR professional.

Generate a professional {email_type} email.

This email will be sent to multiple {person_type.lower()}s.

Email Type: {email_type}

Company Name:
{company}

Additional Instructions:
{additional_details}

IMPORTANT:

Use the placeholder {{Name}} instead of an actual name.

Return ONLY the email in the following format.

Subject:
<subject>

Body:

Dear {{Name}},

...

Regards,
HR Team
"""

            try:

                response = ollama.chat(
                    model="llama3.2:latest",
                    messages=[
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                )

                email_output = response["message"]["content"]

                # Save generated email
                st.session_state["generated_email"] = email_output

                st.success("✅ Email Generated Successfully")

            except Exception as e:

                st.error(f"Error: {e}")




# -----------------------------
# Extract Subject & Body
# -----------------------------
def extract_subject_body(email_text):

    subject = "Recruitment Update"
    body = email_text

    if "Subject:" in email_text:

        lines = email_text.splitlines()

        for i, line in enumerate(lines):

            if line.lower().startswith("subject:"):

                subject = line.replace("Subject:", "").strip()

                body = "\n".join(lines[i + 1:]).strip()

                break

    return subject, body


# Generated Email Preview

if "generated_email" in st.session_state:

    st.subheader("📧 Generated Email Preview")

    st.text_area(
        "Email Content",
        value=st.session_state["generated_email"],
        height=450,
        key="generated_email_preview",
        disabled=True
    )
    st.divider()



# -----------------------------
# Send Emails
# -----------------------------
st.divider()
st.subheader("📨 Send Emails")

if st.button("📨 Send Emails", use_container_width=True):

    if "generated_email" not in st.session_state:
        st.warning("Generate the email first.")

    elif len(selected_recipients) == 0:
        st.warning("Please select at least one recipient.")

    else:

        subject, body = extract_subject_body(
            st.session_state["generated_email"]
        )

        progress = st.progress(0)
        status_box = st.empty()

        success = []
        failed = []

        total = len(selected_recipients)

        for index, recipient_name in enumerate(selected_recipients):

            row = filtered_df[
                filtered_df["name"] == recipient_name
            ].iloc[0]

            personalized_subject = subject
            personalized_body = body

            replacements = {
                # Curly braces
                "{Name}": row["name"],
                "{Role}": role,
                "{Position}": role,
                "{Company}": company,
                "{InterviewDate}": str(interview_date),
                "{Date}": str(interview_date),

                # Square brackets
                "[Name]": row["name"],
                "[Job Title]": role,
                "[Role]": role,
                "[Position]": role,
                "[Company Name]": company,
                "[Company]": company,
                "[Interview Date]": str(interview_date),
                "[InterviewDate]": str(interview_date),
                "[Date]": str(interview_date),
                "[Insert Date]": str(interview_date),
            }

            for key, value in replacements.items():
                personalized_subject = personalized_subject.replace(key, str(value))
                personalized_body = personalized_body.replace(key, str(value))

            email_success, message = email_utils.send_email(
                row["email"],
                personalized_subject,
                personalized_body
            )

            if email_success:
                success.append(row["name"])
            else:
                failed.append(f"{row['name']} - {message}")

            progress.progress((index + 1) / total)
            status_box.info(f"Sending {index + 1} of {total}...")

        progress.empty()
        status_box.empty()

        st.success(f"✅ Processed {total} email(s).")

        col1, col2 = st.columns(2)

        with col1:
            st.metric("Successful", len(success))

        with col2:
            st.metric("Failed", len(failed))

        if failed:
            with st.expander("Failed Emails"):
                st.write(failed)

        if len(failed) == 0:
            st.balloons()