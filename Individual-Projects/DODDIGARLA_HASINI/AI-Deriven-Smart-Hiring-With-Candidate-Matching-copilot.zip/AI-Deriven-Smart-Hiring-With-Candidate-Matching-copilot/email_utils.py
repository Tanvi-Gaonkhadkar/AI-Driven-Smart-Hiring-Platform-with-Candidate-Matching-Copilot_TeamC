"""
email_utils.py
--------------
Sends hiring-related emails (offer, rejection, interview invite, etc.)
to candidates or employees from your configured company mailbox.

CREDENTIALS SETUP (.streamlit/secrets.toml):

    [email]
    address = "your_company_email@gmail.com"
    app_password = "16-character-app-password"
    sender_name = "AI Recruitment Copilot"

GMAIL APP PASSWORD (required — your normal Gmail password will NOT work):
    1. Go to https://myaccount.google.com/security
    2. Enable 2-Step Verification if not already on
    3. Go to https://myaccount.google.com/apppasswords
    4. Generate an app password for "Mail" and paste the 16-character
       code (no spaces) into secrets.toml as app_password

USING A DIFFERENT PROVIDER (Outlook/Office365, custom domain, etc.):
    Just change SMTP_HOST / SMTP_PORT below. Common values:
        Gmail:            smtp.gmail.com : 465 (SSL)
        Outlook/Office365: smtp.office365.com : 587 (STARTTLS)
        Yahoo:            smtp.mail.yahoo.com : 465 (SSL)
"""

import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import streamlit as st

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 465  # SSL port. If you switch to Outlook/587, use send_email_starttls below.


def send_email(to_email: str, subject: str, body: str, is_html=False):
    try:
        email_cfg = st.secrets["email"]

        sender_address = email_cfg["address"]
        sender_password = email_cfg["app_password"]
        sender_name = email_cfg.get("sender_name", "Recruitment Team")

        msg = MIMEMultipart()
        msg["From"] = f"{sender_name} <{sender_address}>"
        msg["To"] = to_email
        msg["Subject"] = subject

        msg.attach(MIMEText(body, "html" if is_html else "plain"))

        context = ssl.create_default_context()

        with smtplib.SMTP_SSL(
            SMTP_HOST,
            SMTP_PORT,
            context=context
        ) as server:

            server.login(sender_address, sender_password)
            server.sendmail(
                sender_address,
                to_email,
                msg.as_string()
            )

        return True, "Email sent successfully."

    except Exception as e:
        return False, str(e)


def send_email_starttls(to_email: str, subject: str, body: str, is_html: bool = False) -> tuple[bool, str]:
    """Alternative sender for providers using STARTTLS on port 587
    (e.g. Outlook/Office365). Swap this in if you're not using Gmail."""
    try:
        email_cfg = st.secrets["email"]
        sender_address = email_cfg["address"]
        sender_password = email_cfg["app_password"]
        sender_name = email_cfg.get("sender_name", "Recruitment Team")
    except KeyError:
        return False, "Email credentials not found. Please add [email] section to secrets.toml."

    msg = MIMEMultipart()
    msg["From"] = f"{sender_name} <{sender_address}>"
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "html" if is_html else "plain"))

    try:
        with smtplib.SMTP("smtp.office365.com", 587) as server:
            server.starttls(context=ssl.create_default_context())
            server.login(sender_address, sender_password)
            server.sendmail(sender_address, to_email, msg.as_string())
        return True, f"Email sent successfully to {to_email}"
    except Exception as e:
        return False, f"Failed to send email: {e}"


def send_bulk_emails(recipients: list[dict], subject_template: str, body_template: str, is_html: bool = False):
    """
    Sends personalized emails to multiple candidates/employees at once.

    recipients: list of dicts, each containing at minimum {"email": ..., "name": ...}
                plus any other fields you want to substitute (e.g. "job_title").
    subject_template / body_template: strings using Python .format() placeholders,
                e.g. "Hi {name}, your interview for {job_title} is confirmed."

    Returns a list of (email, success, message) tuples for building a results table.
    """
    results = []
    for r in recipients:
        try:
            subject = subject_template.format(**r)
            body = body_template.format(**r)
        except KeyError as e:
            results.append((r.get("email", "unknown"), False, f"Missing template field: {e}"))
            continue

        success, message = send_email(r["email"], subject, body, is_html=is_html)
        results.append((r["email"], success, message))
    return results
