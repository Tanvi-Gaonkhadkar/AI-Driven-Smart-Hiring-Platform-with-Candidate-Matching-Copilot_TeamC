import streamlit as st

# MUST be the first Streamlit command
st.set_page_config(
    page_title="AI Recruitment Copilot",
    layout="wide"
)

from login import require_login
from sidebar import show_sidebar

# Login first
require_login()

# Sidebar after login
show_sidebar()

import pandas as pd
import plotly.express as px
from pathlib import Path

# Hide default Streamlit navigation
st.markdown("""
<style>
[data-testid="stSidebarNav"]{
    display:none;
}
</style>
""", unsafe_allow_html=True)

# -----------------------------
# Load Data
# -----------------------------
DATA_DIR = Path(".")


@st.cache_data
def load_csv(path: Path):
    try:
        df = pd.read_csv(path)
        df.columns = df.columns.str.lower().str.strip()
        return df
    except FileNotFoundError:
        st.error(f"{path.name} not found.")
        return pd.DataFrame()
    except Exception as e:
        st.error(e)
        return pd.DataFrame()


candidate_df = load_csv(DATA_DIR / "Candidates.csv")
job_df = load_csv(DATA_DIR / "job.csv")

required_candidate_cols = {
    "status",
    "education",
}

required_job_cols = {
    "location",
    "status",
    "job_title",
    "employment_type",
}

if (
    candidate_df.empty
    or not required_candidate_cols.issubset(candidate_df.columns)
):
    st.error("Candidates.csv is missing required columns.")
    st.stop()

if (
    job_df.empty
    or not required_job_cols.issubset(job_df.columns)
):
    st.error("job.csv is missing required columns.")
    st.stop()

# -----------------------------
# Dashboard
# -----------------------------
st.title("🤖 AI-Driven Smart Hiring With Candidates Matching Copilot")
st.caption(
    "Central dashboard overview of recruitment pipeline and workforce analytics."
)

# -----------------------------
# KPIs
# -----------------------------
c1, c2, c3, c4 = st.columns(4)

c1.metric("👥 Total Candidates", len(candidate_df))
c2.metric(
    "⭐ Applied",
    len(candidate_df[candidate_df["status"].str.lower() == "applied"]),
)
c3.metric(
    "🎯 Shortlisted",
    len(candidate_df[candidate_df["status"].str.lower() == "shortlisted"]),
)
c4.metric(
    "✅ Hired",
    len(candidate_df[candidate_df["status"].str.lower() == "hired"]),
)

st.divider()

# -----------------------------
# Charts Row 1
# -----------------------------
left, right = st.columns(2)

with left:
    st.subheader("🎓 Applications by Education")

    education = (
        candidate_df["education"]
        .fillna("Unknown")
        .str.title()
        .value_counts()
        .reset_index()
    )

    education.columns = ["Education", "Candidates"]

    fig = px.bar(
        education,
        x="Education",
        y="Candidates",
        color="Candidates",
        text="Candidates",
    )

    fig.update_layout(showlegend=False)

    st.plotly_chart(fig, use_container_width=True)

with right:
    st.subheader("📍 Hiring Locations")

    location = (
        job_df["location"]
        .fillna("Unknown")
        .str.title()
        .value_counts()
        .reset_index()
    )

    location.columns = ["Location", "Jobs"]

    fig = px.bar(
        location,
        x="Jobs",
        y="Location",
        orientation="h",
        color="Jobs",
        text="Jobs",
    )

    fig.update_layout(showlegend=False)

    st.plotly_chart(fig, use_container_width=True)

# -----------------------------
# Charts Row 2
# -----------------------------
left, right = st.columns(2)

with left:

    st.subheader("💼 Active Job Openings")

    openings = (
        job_df[
            job_df["status"].str.lower() == "open"
        ]["job_title"]
        .fillna("Unknown")
        .value_counts()
        .reset_index()
    )

    openings.columns = ["Role", "Openings"]

    fig = px.bar(
        openings,
        x="Role",
        y="Openings",
        color="Openings",
        text="Openings",
    )

    fig.update_layout(showlegend=False)

    st.plotly_chart(fig, use_container_width=True)

with right:

    st.subheader("📋 Employment Type")

    employment = (
        job_df["employment_type"]
        .fillna("Unknown")
        .str.title()
        .value_counts()
        .reset_index()
    )

    employment.columns = ["Type", "Count"]

    fig = px.pie(
        employment,
        names="Type",
        values="Count",
        hole=0.55,
    )

    fig.update_traces(textposition="inside", textinfo="percent+label")

    st.plotly_chart(fig, use_container_width=True)

st.divider()

# -----------------------------
# Candidate Status
# -----------------------------
st.subheader("👥 Candidate Status")

status = (
    candidate_df["status"]
    .fillna("Unknown")
    .str.title()
    .value_counts()
    .reset_index()
)

status.columns = ["Status", "Count"]

fig = px.pie(
    status,
    names="Status",
    values="Count",
    hole=0.6,
)

fig.update_traces(textposition="inside", textinfo="percent+label")

st.plotly_chart(fig, use_container_width=True)

st.divider()

# -----------------------------
# AI Insights
# -----------------------------
st.subheader("🤖 AI Insights")

st.success("Top candidates have Resume Scores above 85.")
st.info("Most applicants applied for AI Engineer and Data Scientist roles.")
st.warning("Candidates with Resume Scores below 60 may require additional screening.")

st.divider()

# -----------------------------
# Recent Applications
# -----------------------------
st.subheader("📋 Recent Applications")

st.dataframe(candidate_df.head(10), use_container_width=True)