"""
email_page_example.py
----------------------
Drop-in example for your "AI Email Generator" page — shows the full flow:
pick a candidate/employee -> AI drafts the email (your existing Llama 3.2
logic) -> user reviews/edits -> clicks Send -> email_utils.py delivers it.

This is a reference page, not meant to replace your whole app — copy the
relevant parts into your existing AI Email Generator page.
"""

import streamlit as st
from email_utils import send_email, send_bulk_emails

st.header("📧 AI Email Generator")

# --- 1. Select recipient type & candidate/employee -------------------------
col1, col2 = st.columns(2)
with col1:
    recipient_type = st.selectbox("Sending to", ["Candidate", "Employee"])
with col2:
    email_purpose = st.selectbox(
        "Email purpose",
        ["Interview Invitation", "Offer Letter", "Rejection", "Onboarding", "Custom"],
    )

recipient_name = st.text_input("Recipient Name", placeholder="e.g. Sai Verma")
recipient_email = st.text_input("Recipient Email", placeholder="e.g. sai.verma@example.com")

# --- 2. AI-generated draft (plug your existing Llama 3.2 call in here) -----
# Replace this block with your existing generation logic — this is just a
# placeholder so the page runs standalone.
if "draft_subject" not in st.session_state:
    st.session_state.draft_subject = ""
    st.session_state.draft_body = ""

if st.button("✨ Generate Draft with AI"):
    # >>> Replace the two lines below with your Llama 3.2 generation call <<<
    st.session_state.draft_subject = f"{email_purpose} — Update on your application"
    st.session_state.draft_body = (
        f"Dear {recipient_name or '[Candidate Name]'},\n\n"
        f"This is regarding your {email_purpose.lower()}. "
        f"[AI-generated content goes here]\n\n"
        f"Best regards,\nHR Team"
    )
    st.success("Draft generated. Review and edit below before sending.")

# --- 3. Review / edit the draft --------------------------------------------
subject = st.text_input("Subject", value=st.session_state.draft_subject)
body = st.text_area("Email Body", value=st.session_state.draft_body, height=250)

# --- 4. Send -----------------------------------------------------------
if st.button("📤 Send Email", type="primary"):
    if not recipient_email:
        st.error("Please enter a recipient email address.")
    elif not subject or not body:
        st.error("Subject and body cannot be empty.")
    else:
        with st.spinner("Sending..."):
            success, message = send_email(recipient_email, subject, body)
        if success:
            st.success(message)
        else:
            st.error(message)

st.markdown("---")

# --- Optional: bulk send to multiple selected candidates -------------------
with st.expander("Send to multiple candidates at once"):
    st.caption(
        "Use {name} and {job_title} etc. as placeholders — they'll be filled "
        "in per recipient from your candidate table."
    )
    bulk_subject = st.text_input("Bulk Subject Template", value="Interview Invitation — {job_title}")
    bulk_body = st.text_area(
        "Bulk Body Template",
        value="Dear {name},\n\nWe'd like to invite you to interview for the {job_title} role.\n\nBest regards,\nHR Team",
        height=180,
    )
    st.caption("Example: connect this to your `Selected Candidates` table from the Multi-Candidate Analysis tab.")

    example_recipients = [
        {"name": "Sai Verma", "email": "sai.verma@example.com", "job_title": "Software Engineer"},
        {"name": "Kiran Naidu", "email": "kiran.naidu@example.com", "job_title": "Software Engineer"},
    ]

    if st.button("📤 Send Bulk Emails"):
        with st.spinner("Sending bulk emails..."):
            results = send_bulk_emails(example_recipients, bulk_subject, bulk_body)
        for email, success, message in results:
            if success:
                st.success(f"{email}: {message}")
            else:
                st.error(f"{email}: {message}")
