# 🤖 HR ChatBot AI - Implementation Guide

## Overview

I've created **two comprehensive chatbot solutions** for your AI Recruitment and Talent Management system:

### 1. **HR ChatBot AI** (Basic Version)
- **File:** `pages/8_HR_ChatBot_AI.py`
- **Best for:** Quick insights and rule-based responses
- **No LLM required** - works offline
- Perfect for organizations not yet using AI models

### 2. **HR ChatBot AI Pro** (Advanced LLM Version)
- **File:** `pages/8_HR_ChatBot_AI_Pro.py`
- **Best for:** Intelligent, context-aware responses
- **Requires:** Ollama + llama3.2 model
- Provides sophisticated HR advice and analysis

---

## Features

### ✨ Common Features (Both Versions)

✅ **Real-time Chat Interface**
- Clean, modern chat UI with user and bot messages
- Message history within session
- Export chat history as JSON

✅ **Smart Intent Recognition**
- Detects hiring, recruitment, candidates, salary, skills, analytics, performance, training queries
- Provides contextual responses

✅ **Data Integration**
- Automatically loads Candidates.csv, job.csv, employee_details.csv
- Provides real-time metrics:
  - Total candidates in pipeline
  - Open job positions
  - Active employees
  - Candidate status distribution
  - Job posting status

✅ **Quick Action Buttons**
- 1-click access to common queries
- Pre-built recommendation prompts
- Suggested questions sidebar

✅ **HR Expertise Areas**
1. 💼 **Hiring & Recruitment** - Job openings, candidate pipeline
2. 👥 **Candidate Assessment** - Matching, skills analysis
3. 💰 **Compensation** - Salary insights, benchmarking
4. 🎓 **Training & Development** - Skill gap analysis
5. ⭐ **Performance Management** - Evaluations, feedback
6. 📊 **Analytics & Metrics** - Reporting, trends
7. 💡 **Best Practices** - HR strategies and recommendations

---

## Installation & Setup

### Prerequisites
```bash
# Already installed (verify these are installed):
pip list | grep -i streamlit
pip list | grep -i pandas
pip list | grep -i plotly
```

### For Pro Version (With Ollama)

**Step 1: Install Ollama**
- Download from: https://ollama.ai
- Install and start Ollama service

**Step 2: Pull llama3.2 Model**
```bash
ollama pull llama3.2
# This downloads ~5GB model (one-time)
# Once downloaded, Ollama keeps it ready
```

**Step 3: Verify Installation**
```bash
python test_llama.py
# Should show a response about AI recruitment assistant
```

**Step 4: Install Python Ollama Client**
```bash
pip install ollama
```

---

## Running the Chatbot

### Option 1: Basic Chatbot (No LLM)
```bash
cd C:\Users\honey\Ai_recrutment_and_talent_management
streamlit run pages/8_HR_ChatBot_AI.py
```

### Option 2: Pro Chatbot (With LLM - Recommended)
```bash
# Start Ollama first (if not running)
ollama serve

# In another terminal:
cd C:\Users\honey\Ai_recrutment_and_talent_management
streamlit run pages/8_HR_ChatBot_AI_Pro.py
```

### Option 3: Run Main App (All Pages)
```bash
streamlit run app.py
# Navigate to 🤖 HR ChatBot AI from sidebar
```

---

## Usage Guide

### Basic Usage

1. **Open the ChatBot Page**
   - Click "🤖 HR ChatBot AI" in sidebar
   - Wait for data to load

2. **Ask a Question**
   - Type your question in the input box
   - Click "Send ➤" or press Enter
   - Wait for response

3. **Use Quick Buttons**
   - Click suggested questions in right sidebar
   - Instant pre-built responses

4. **Export Conversation**
   - Click "📥 Export Chat"
   - Download as JSON for records

### Example Queries

**Hiring & Recruitment:**
- "Show hiring status"
- "What are the current job openings?"
- "How many candidates do we have in the pipeline?"

**Candidate Analysis:**
- "Tell me about candidates"
- "What's the education distribution among candidates?"
- "Show candidate status breakdown"

**Talent Development:**
- "What training programs should we implement?"
- "What skills are in-demand?"
- "How can we address skill gaps?"

**Performance & Analytics:**
- "Show analytics"
- "Give me performance insights"
- "What are the key HR metrics?"

**General Advice:**
- "Recommendations for hiring"
- "Best practices for retention"
- "How can we improve candidate experience?"

---

## Data Integration

### Supported CSV Files

| File | Purpose | Required Columns |
|------|---------|-----------------|
| `Candidates.csv` | Candidate pool | status, education |
| `job.csv` | Job postings | job_title, location, status, employment_type |
| `employee_details.csv` | Employee data | (flexible) |

### Data Automatically Used

✅ Candidate count and distribution
✅ Job openings by title and location
✅ Employee statistics
✅ Status tracking (active, inactive, hired, etc.)
✅ Education level analysis
✅ Skill matching capabilities

---

## Architecture

### Basic Version Flow
```
User Input
    ↓
Intent Classification (Keywords)
    ↓
Response Generation (Rule-Based)
    ↓
Display in Chat UI
    ↓
Maintain History
```

### Pro Version Flow
```
User Input
    ↓
Intent Classification
    ↓
Build HR Context (from data)
    ↓
Send to Ollama LLM (llama3.2)
    ↓
Generate Intelligent Response
    ↓
Display in Chat UI
    ↓
Maintain History
```

---

## Customization

### Add Custom Questions

Edit `pages/8_HR_ChatBot_AI.py` or `pages/8_HR_ChatBot_AI_Pro.py`:

```python
# Add to CHATBOT_RESPONSES dictionary:
"custom_intent": {
    "keywords": ["keyword1", "keyword2"],
    "response": lambda: your_custom_response()
}
```

### Add Custom Response Function

```python
def your_custom_response():
    """Your custom logic here"""
    insights = []
    insights.append("Your insight here")
    return "\n".join(insights)
```

### Modify LLM System Prompt

In Pro version, edit `get_hr_context()` function to add custom HR expertise areas.

---

## Troubleshooting

### Issue: "AI Model Not Available"
**Solution:** 
- Ensure Ollama is running: `ollama serve`
- Verify llama3.2 is installed: `ollama pull llama3.2`
- Check Python client: `pip install ollama`

### Issue: "File not found: Candidates.csv"
**Solution:**
- Verify files are in: `C:\Users\honey\Ai_recrutment_and_talent_management\`
- Files must be named exactly: `Candidates.csv`, `job.csv`, `employee_details.csv`

### Issue: Slow Responses
**Solution:**
- First response from LLM can take 5-10s
- Subsequent queries are faster
- Ensure Ollama has sufficient RAM

### Issue: Chat Not Updating
**Solution:**
- Clear browser cache
- Hard refresh (Ctrl+Shift+R)
- Check browser console for errors

---

## Performance Tips

✅ **For Speed:**
- Use Basic version for quick responses
- Pre-cache data with `@st.cache_data`
- Keep chat history under 50 messages

✅ **For Better Responses:**
- Be specific in questions
- Include context (role, department, etc.)
- Ask follow-up questions for refinement

✅ **For Reliability:**
- Keep Ollama running in background
- Monitor system RAM usage
- Restart Ollama if responses degrade

---

## Advanced: Integration Points

### Connect to Other Pages

The chatbot can reference data from:
- 📄 JD & Resume Matching AI
- 🎤 Interview Question Generator AI
- 🗂️ Resume Chat & Candidate Comparison
- ✅ Hiring Recommendation AI
- 📊 Talent Insights & Skill Gap Analyzer
- 📧 AI Email Generator
- 📑 Report Generator

### Extend with APIs

Add external integrations:
```python
# In get_hr_context():
external_data = fetch_from_api()
context += f"External Data: {external_data}"
```

---

## File Structure

```
pages/
├── 8_HR_ChatBot_AI.py          # Basic version
├── 8_HR_ChatBot_AI_Pro.py      # Pro version with LLM
```

Both files are automatically added to sidebar via `sidebar.py`

---

## Support & Help

### Quick Help Commands (In Chat)
- Type "help" → Shows all commands
- Type "?" → General assistance
- Type "commands" → List available commands

### View About Section
- Click "ℹ️ About This ChatBot" expander
- Shows features and example questions

---

## Security & Privacy

✅ **Local Processing**: All data stays on your machine
✅ **No Cloud Upload**: Ollama runs locally
✅ **Export Control**: You control what's exported
✅ **Session Isolation**: Each session is independent

---

## Future Enhancements

Potential additions:
- 📧 Email integration for direct hiring actions
- 📊 Real-time dashboard updates
- 🔄 Multi-language support
- 🎯 Personalized recommendations
- 🔐 User authentication & roles
- 📱 Mobile app version

---

## License & Attribution

These chatbots are part of your AI Recruitment and Talent Management System.

---

**Last Updated:** 2024
**Version:** 2.0 (Pro + Basic)
**Status:** Production Ready ✅
