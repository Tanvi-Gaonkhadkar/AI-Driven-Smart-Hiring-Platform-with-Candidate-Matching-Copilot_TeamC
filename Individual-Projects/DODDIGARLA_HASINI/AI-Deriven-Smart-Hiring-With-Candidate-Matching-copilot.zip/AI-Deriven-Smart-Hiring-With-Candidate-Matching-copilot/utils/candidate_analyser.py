import re


SKILLS = [
    "python",
    "java",
    "c",
    "c++",
    "sql",
    "mysql",
    "html",
    "css",
    "javascript",
    "react",
    "node.js",
    "django",
    "flask",
    "git",
    "github",
    "docker",
    "kubernetes",
    "aws",
    "azure",
    "gcp",
    "power bi",
    "tableau",
    "excel",
    "machine learning",
    "deep learning",
    "tensorflow",
    "pytorch",
    "nlp",
    "streamlit",
    "pandas",
    "numpy"
]

def extract_candidate_info(resume_text):

    email = ""
    phone = ""
    name = "Not Found"

    email_match = re.search(
        r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}",
        resume_text
    )

    if email_match:
        email = email_match.group()

    phone_match = re.search(
        r"(\+?\d[\d\s-]{8,}\d)",
        resume_text
    )

    if phone_match:
        phone = phone_match.group()

    for line in resume_text.split("\n"):
        line = line.strip()

        if line:
            name = line
            break

    return {
        "Name": name,
        "Email": email,
        "Phone": phone
    }

def extract_skills(text):

    text = text.lower()
    skills = []

    for skill in SKILLS:
        if skill in text:
            skills.append(skill.title())

    return sorted(list(set(skills)))

def analyze_candidate(resume_text, job_description):

    candidate = extract_candidate_info(resume_text)

    resume_skills = extract_skills(resume_text)
    jd_skills = extract_skills(job_description)

    matching = sorted(list(set(resume_skills) & set(jd_skills)))
    missing = sorted(list(set(jd_skills) - set(resume_skills)))

    if len(jd_skills) == 0:
        score = 0
    else:
        score = round(len(matching) / len(jd_skills) * 100)

    if score >= 85:
        recommendation = "🟢 Highly Recommended"
    elif score >= 70:
        recommendation = "🟢 Recommended"
    elif score >= 50:
        recommendation = "🟡 Consider for Interview"
    else:
        recommendation = "🔴 Not Recommended"

    return {
        "candidate": candidate,
        "score": score,
        "matching_skills": matching,
        "missing_skills": missing,
        "recommendation": recommendation
    }