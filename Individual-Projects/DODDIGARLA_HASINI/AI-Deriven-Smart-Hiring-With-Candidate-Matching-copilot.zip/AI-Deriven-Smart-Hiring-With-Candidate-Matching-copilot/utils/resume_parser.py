from pypdf import PdfReader
from docx import Document

def extract_resume_text(uploaded_resume):

    file_type = uploaded_resume.name.split(".")[-1].lower()

    if file_type == "pdf":

        reader = PdfReader(uploaded_resume)
        text = ""

        for page in reader.pages:
            page_text = page.extract_text()

            if page_text:
                text += page_text + "\n"

        return text

    elif file_type == "docx":

        doc = Document(uploaded_resume)
        return "\n".join([para.text for para in doc.paragraphs])

    elif file_type == "txt":

        return uploaded_resume.read().decode("utf-8")

    return ""