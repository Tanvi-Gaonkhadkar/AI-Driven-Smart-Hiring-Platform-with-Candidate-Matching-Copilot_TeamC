# 🤖 HR ChatBot - Visual Setup & Usage Guide

## 📚 Documentation Files Created

```
Ai_recrutment_and_talent_management/
├── 📄 QUICKSTART.md                    ← START HERE! (5 min read)
├── 📄 CHATBOT_IMPLEMENTATION_SUMMARY.md ← Overview (10 min read)
├── 📄 CHATBOT_README.md                ← Full guide (20 min read)
├── 📄 CHATBOT_ARCHITECTURE.md          ← Technical (15 min read)
├── 📄 SETUP_VISUAL_GUIDE.md            ← This file
│
├── pages/
│   ├── 8_HR_ChatBot_AI.py              ✨ BASIC CHATBOT
│   └── 8_HR_ChatBot_AI_Pro.py          ✨ PRO CHATBOT
│
└── Data Files (auto-loaded):
    ├── Candidates.csv
    ├── job.csv
    └── employee_details.csv
```

---

## 🎯 Which ChatBot Should I Use?

### 🟢 Use BASIC ChatBot If:
- ✅ You want instant setup (no installation needed)
- ✅ You want fast responses (<100ms)
- ✅ You want to work offline
- ✅ You just want quick HR insights
- ✅ You don't have Ollama installed yet

**Command:**
```bash
streamlit run pages/8_HR_ChatBot_AI.py
```

### 🟣 Use PRO ChatBot If:
- ✅ You want AI-powered intelligent responses
- ✅ You want contextual understanding
- ✅ You want more natural conversations
- ✅ You have Ollama installed and running
- ✅ You want 95%+ accuracy

**Command:**
```bash
streamlit run pages/8_HR_ChatBot_AI_Pro.py
```

---

## 🚀 Quick Setup (5 Minutes)

### Step 1: Open Terminal
```
Windows: Press Ctrl + ~ (or search "PowerShell")
```

### Step 2: Navigate to Project
```bash
cd C:\Users\honey\Ai_recrutment_and_talent_management
```

### Step 3: Run ChatBot
```bash
# BASIC VERSION (recommended first time)
streamlit run pages/8_HR_ChatBot_AI.py

# OR PRO VERSION (if you have Ollama)
streamlit run pages/8_HR_ChatBot_AI_Pro.py
```

### Step 4: Browser Opens
```
Your chatbot opens at: http://localhost:8501
If not, copy that URL to your browser
```

### Step 5: Start Chatting! 🎉
```
Type your question and press Enter
Or click quick buttons in the sidebar
```

---

## 💻 Setup: Pro Version (With AI)

### Phase 1: Install Ollama (10 minutes)

**Step 1:** Download Ollama
```
Visit: https://ollama.ai
Click: Download
Choose: Windows
```

**Step 2:** Install
```
Run: OllamaSetup.exe
Follow: Installation wizard
Accept: Default options
```

**Step 3:** Download AI Model
```bash
# Open new PowerShell/Terminal
ollama pull llama3.2
# This downloads ~5GB (one time)
# Progress shown in terminal
```

**Step 4:** Verify Installation
```bash
python test_llama.py
# Should show response about AI recruitment
```

### Phase 2: Install Python Client (2 minutes)

**Step 5:** Install Python Package
```bash
pip install ollama
```

### Phase 3: Run Pro ChatBot (2 minutes)

**Step 6:** Start Ollama Service
```bash
ollama serve
# Leave this running in background
```

**Step 7:** Run ChatBot (New Terminal)
```bash
cd C:\Users\honey\Ai_recrutment_and_talent_management
streamlit run pages/8_HR_ChatBot_AI_Pro.py
```

---

## 🖥️ ChatBot Interface Overview

### Basic Version Interface
```
┌─────────────────────────────────────────────────┐
│ 🤖 HR ChatBot AI Assistant                      │
├─────────────────────────────────────────────────┤
│                                                   │
│  ┌──────────────────────────┐  ┌─────────────┐ │
│  │  Chat Messages           │  │  Quick Info │ │
│  │                          │  │             │ │
│  │ User: "Show me jobs"    │  │ 👥 Candidates │ │
│  │                          │  │ 💼 Job Count  │ │
│  │ Bot: "📋 Current Job..." │  │ 👔 Employees  │ │
│  │                          │  │             │ │
│  │  ┌────────────────────┐  │  │ [Buttons]   │ │
│  │  │ Your question here │  │  │             │ │
│  │  │ [Send ➤]          │  │  │             │ │
│  │  └────────────────────┘  │  └─────────────┘ │
│  └──────────────────────────┘                   │
│                                                   │
│ [🗑️ Clear] [💡 Tip] [📥 Export]               │
└─────────────────────────────────────────────────┘
```

### Pro Version Interface (Same + Status)
```
┌─────────────────────────────────────────────────┐
│ 🤖 HR ChatBot AI - Pro Edition                  │
│ ✅ AI Model Ready | 📊 Data Loaded | 💬 Stats   │
├─────────────────────────────────────────────────┤
│ [Same as above + AI badge on responses]         │
└─────────────────────────────────────────────────┘
```

---

## 🎮 How to Use the ChatBot

### Method 1: Type Your Question
```
1. Click input field at bottom
2. Type your question
3. Press Enter or click [Send ➤]
4. Wait for response
5. Continue chatting
```

**Example Questions:**
- "Show hiring status"
- "Tell me about candidates"
- "What training should we do?"
- "Show me analytics"

### Method 2: Quick Buttons
```
Right sidebar has these buttons:
  💼 Hiring Status
  👥 Candidates  
  📊 Analytics
  🎓 Training
  ❓ Help

Just click any button!
```

### Method 3: Smart Help
```
Type: "help"
Bot shows: All available commands
```

---

## 📊 What Each Response Type Shows

### 💼 Hiring Status
```
Shows:
• Number of open job positions
• Top in-demand roles
• Total candidates in pipeline
• Candidate status distribution
```

### 👥 Candidate Insights
```
Shows:
• Total candidate count
• Education distribution
• Status breakdown
• Qualification levels
```

### 💰 Salary Insights
```
Shows:
• Typical salary ranges
• Compensation by level
• Market recommendations
• Negotiation tips
```

### 🎓 Training Recommendations
```
Shows:
• Skill gaps identified
• Recommended programs
• Learning platforms
• Career development paths
```

### 📊 Analytics
```
Shows:
• Current pipeline metrics
• Distribution charts
• Key performance indicators
• Hiring funnel data
```

---

## ✨ Features Demonstration

### Chat History Example
```
┌─────────────────────────────────────┐
│ You: "Show hiring status"           │
│                                      │
│ Bot: "📋 Current Job Openings:       │
│       15 positions available         │
│                                      │
│       👥 Total Candidates: 342       │
│                                      │
│       Candidate Status:              │
│       • Applied: 150                 │
│       • Shortlisted: 120             │
│       • Hired: 22"                  │
│                                      │
│ You: "Tell me about training"       │
│                                      │
│ Bot: "📚 Training & Development:     │
│       Recommended Programs:          │
│       • Python for Data Analysis     │
│       • Cloud Computing (AWS/Azure)  │
│       • Leadership Skills"           │
│                                      │
│ [🗑️ Clear All]  [📥 Export]        │
└─────────────────────────────────────┘
```

### Export Feature
```
Click: 📥 Export Chat
Result: JSON file downloads with:
  • Entire conversation
  • Timestamps
  • Ready to share/analyze
```

---

## 🔍 Understanding Your Data

### What Gets Loaded Automatically

**From Candidates.csv:**
```
✅ Total candidate count
✅ Status (Applied, Hired, etc.)
✅ Education level
✅ Available skills
✅ Application timeline
```

**From job.csv:**
```
✅ Open positions count
✅ Job titles
✅ Locations
✅ Employment types
✅ Job status
```

**From employee_details.csv:**
```
✅ Total employees
✅ Departments
✅ Roles
✅ Performance data
✅ Tenure info
```

---

## 🎯 Common Use Cases

### Use Case 1: Daily Standup
```
HR Manager: "What's our hiring status?"
ChatBot: [Shows pipeline, open roles, numbers]
Result: Quick update for team meeting ✅
```

### Use Case 2: Candidate Assessment
```
Recruiter: "Show candidate education distribution"
ChatBot: [Shows qualification breakdown]
Result: Understand candidate pool 📊
```

### Use Case 3: Training Planning
```
HR Director: "What skills are in-demand?"
ChatBot: [Shows market trends, recommendations]
Result: Plan training budget 🎓
```

### Use Case 4: Analytics Review
```
Analytics Team: "Show me key metrics"
ChatBot: [Displays all HR KPIs]
Result: Create monthly report 📈
```

### Use Case 5: Quick Advice
```
Hiring Manager: "Best practices for retention?"
ChatBot: [Shows proven strategies]
Result: Implement improvements 💡
```

---

## 🆘 Troubleshooting Quick Links

### "ChatBot not showing in sidebar"
```
Solution: Refresh page (Ctrl+Shift+R)
Check: sidebar.py has chatbot entries
Verify: Files exist at pages/8_HR_ChatBot_AI.py
```

### "CSV files not loading"
```
Check file names exactly:
  ✅ Candidates.csv (NOT candidates.csv)
  ✅ job.csv
  ✅ employee_details.csv
Location: C:\Users\honey\Ai_recrutment_and_talent_management\
```

### "Pro version showing 'Model not available'"
```
1. Install Ollama: https://ollama.ai
2. Pull model: ollama pull llama3.2
3. Start service: ollama serve
4. Refresh ChatBot page
```

### "Slow responses"
```
Normal: First response 5-10 seconds
Fast: Subsequent responses 2-3 seconds
Fix: Ensure Ollama has RAM available
```

---

## 📱 Mobile Usage

### Accessing on Mobile
```
1. Find your computer's IP
   Run: ipconfig (find IPv4 Address)
2. On mobile browser:
   Visit: http://YOUR_IP:8501
3. Works on any device!
```

### Mobile Tips
```
✅ Landscape mode for better view
✅ Quick buttons are larger
✅ Chat history scrolls smoothly
✅ Export works on mobile
```

---

## 🔒 Security Reminders

```
✅ Local processing - data stays on device
✅ No cloud upload - nothing sent online
✅ No login needed - simple access
✅ Session isolation - each chat is independent
✅ Can close anytime - no saving required
```

---

## 📊 Performance Tips

### For Speed
```
1. Use Basic version for instant responses
2. Keep chat history under 50 messages
3. Clear chat periodically
4. Restart if response time degrades
```

### For Better Results
```
1. Be specific in questions
2. Include context (role, department)
3. Ask follow-ups for refinement
4. Use quick buttons for common queries
```

### For Reliability
```
1. Keep Ollama running (Pro version)
2. Monitor system RAM usage
3. Don't run too many apps
4. Close and reopen if issues
```

---

## 📞 Need Help?

### Quick References
- **QUICKSTART.md** - 5 minute setup
- **CHATBOT_README.md** - Complete guide
- **CHATBOT_ARCHITECTURE.md** - Technical details
- **Type "help"** - In-app help

### Common Questions Answered
- Q: Do I need internet? A: No (Basic), Yes initial (Pro)
- Q: Can I use on mobile? A: Yes, via local network
- Q: How private is this? A: 100% local, very private
- Q: Cost? A: Free! (Ollama is free)
- Q: Can I customize? A: Yes! Edit the Python files

---

## 🎓 Learning Path

### Day 1: Get Started
```
1. Read QUICKSTART.md (5 min)
2. Run basic chatbot (5 min)
3. Test 5 different questions (10 min)
Total: 20 minutes
```

### Day 2: Explore Features
```
1. Try all quick buttons
2. Export a conversation
3. Read CHATBOT_README.md
4. Test on another device
Total: 30 minutes
```

### Day 3: Advanced Setup
```
1. Install Ollama
2. Setup Pro version
3. Compare responses
4. Read CHATBOT_ARCHITECTURE.md
Total: 45 minutes
```

### Day 4: Customization
```
1. Modify response types
2. Add custom questions
3. Integrate with team workflow
4. Plan deployment
Total: 60 minutes
```

---

## 🚀 Ready to Start?

### Quick Command Reference
```bash
# Basic ChatBot (instant, no setup)
streamlit run pages/8_HR_ChatBot_AI.py

# Pro ChatBot (AI-powered, requires Ollama)
streamlit run pages/8_HR_ChatBot_AI_Pro.py

# Full App (all features)
streamlit run app.py
```

### Next Steps
1. Pick one command above
2. Copy and paste into terminal
3. Press Enter
4. Browser opens automatically
5. Start asking questions! 🎉

---

## 📈 What You Get

✅ **Immediate** - Start chatting in 30 seconds
✅ **Professional** - Beautiful, clean UI
✅ **Smart** - Understands HR context
✅ **Flexible** - Works offline or with AI
✅ **Secure** - Your data stays private
✅ **Free** - No subscriptions or costs
✅ **Expandable** - Easy to customize
✅ **Documented** - Complete guides included

---

## 🎯 Success Checklist

- [ ] Read QUICKSTART.md
- [ ] Run basic chatbot successfully
- [ ] Ask 3 test questions
- [ ] Export a conversation
- [ ] Share with team
- [ ] (Optional) Setup Pro version
- [ ] (Optional) Customize responses
- [ ] Integrate into workflow

---

**Status:** ✅ Ready to Use
**Version:** 2.0
**Support:** See documentation files

# Happy Chatting! 🤖🚀

Pick your command and run it now! ⬆️
