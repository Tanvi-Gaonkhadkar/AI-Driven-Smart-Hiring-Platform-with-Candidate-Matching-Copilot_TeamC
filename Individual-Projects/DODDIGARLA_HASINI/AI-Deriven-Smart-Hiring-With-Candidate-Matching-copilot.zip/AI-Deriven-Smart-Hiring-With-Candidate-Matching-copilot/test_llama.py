import ollama

response = ollama.chat(
    model="llama3.2",
    messages=[
        {
            "role": "user",
            "content": "You are an AI recruitment assistant. Explain how you can help HR."
        }
    ]
)

print(response["message"]["content"])