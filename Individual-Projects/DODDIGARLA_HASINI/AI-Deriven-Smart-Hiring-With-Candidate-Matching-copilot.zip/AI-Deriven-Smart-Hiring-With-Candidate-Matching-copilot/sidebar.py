import streamlit as st
from login import logout_button


def show_sidebar():

    if not st.session_state.get("logged_in", False):
        return

    with st.sidebar:

        st.title("🤖 AI-Driven Smart Hiring Copilot")

        st.divider()

        st.page_link("app.py", label="🏠 Home")
        st.page_link("pages/2_Job_Openings.py", label="📄 Job Openings")
        st.page_link("pages/3_Interview_Question_Generator.py", label="🎤 Interview Question Generator AI")
        st.page_link("pages/4_Resume_Chat_Comparison.py", label="🗂️ Resume Chat & Candidate Comparison AI")
        st.page_link("pages/5_Hiring_Recommendation.py", label="✅ Hiring Recommendation AI")
        st.page_link("pages/6_Email_Generator.py", label="📧 AI Email Generator")
        st.page_link("pages/7_report_generator.py", label="📑 Report Generator")
        st.page_link("pages/8_HR_ChatBot_AI.py", label="🤖 HR ChatBot AI")
        st.page_link("pages/8_HR_ChatBot_AI_Pro.py", label="🤖 HR ChatBot AI Pro")

        logout_button()